# MaintainInstanceRuns.py
# Description: View details of an InstanceRun, including players, links to edit details and add players
# Author: Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect, traceback, time

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
    # not logged in: redirect to Login
    print redirect.getRedirectHead(redirect.getRelativeURL("Login.py"))
    db.close()
    sess.close()
    quit()    

# logged in: validate user
try:
    cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""", sess.data.get('userName'))          
except:
    # database error
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        # invalid user: redirect to do_logout
        print redirect.getRedirectHead(redirect.getRelativeURL("do_logout.py"))
        db.close()
        sess.close()
        quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A', 'P')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
    # access denied
    print redirect.getRedirectHead(redirect.getRelativeURL("AccessDenied.py"))
    db.close()
    sess.close()
    quit()

#=====================================================================================
# Update logic
#=====================================================================================

sql_addr = """
INSERT INTO Address
VALUES (DEFAULT, %s, %s, %s, %s, %s, %s, %s)
"""

sql_last_addr_id = """ SELECT AddressID FROM Address WHERE AddressID = last_insert_id();"""

sql_pa = """
INSERT INTO PlayerAddress
VALUES (%s, %s, %s, NULL);
"""

params_addr = (form.getfirst('addrLine1'),form.getfirst('addrLine2'),
               form.getfirst('MinorM'),form.getfirst('MajorM'),
               form.getfirst('GoverningDistrict'),
               form.getfirst('PostCode'),
               form.getfirst('Country'))

start_date = time.strftime("%Y-%m-%d")


#sql to determine the most recent address
sql_rec_addr = """
    SELECT StartDate FROM PlayerAddress
    WHERE PlayerID = %s
    ORDER BY StartDate DESC
"""

sql_rec_addr_param = form.getfirst('PlayerID');

#sql to update most entry of player address table
sql_pa_update = """
    UPDATE PlayerAddress
    SET EndDate = %s
    WHERE PlayerID = %s AND StartDate = %s
"""


try:
    cursor = db.cursor()

    #Update the most recent address end date to today
    cursor.execute(sql_rec_addr, sql_rec_addr_param)
    last_addr_startdate = cursor.fetchone()
    if last_addr_startdate is not None:
        sql_pa_update_params = (start_date, form.getfirst('PlayerID'), last_addr_startdate[0])
        cursor.execute(sql_pa_update, sql_pa_update_params)

        
    
    #insert into Address Table
    cursor.execute(sql_addr, params_addr)
    
    #Find the AddressID of the last insert
    cursor.execute(sql_last_addr_id)
    last_addr_id = cursor.fetchone()
    
    #create associated entry in PlayerAddress Table
    cursor.execute(sql_pa, (form.getfirst('PlayerID'), last_addr_id[0], start_date))
    

    
    db.commit()
    cursor.close()
except:
    traceback.print_exc()
    db.rollback()
    cursor.close()
    whereToNext = "CreatePlayerAddress.py?PlayerID=%s" % form.getfirst('PlayerID')

else:
    whereToNext = "ViewPlayerAddress.py?PlayerID=%s&StartDate=%s" % (form.getfirst('PlayerID'), time.strftime("%Y-%m-%d"))

print redirect.getRedirectHead(redirect.getRelativeURL(whereToNext))
    
# clean up
db.close()
sess.close()
