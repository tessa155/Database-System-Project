# Description: Edit Video
# Author: Heng Lin, modified from codes created by Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect, xstr

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
    # not logged in: redirect to Login
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("Login.py")
    db.close()
    sess.close()
    quit()    

# logged in: validate user
try:
    cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""", sess.data.get('userName'))          
except:
    # database error
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        # invalid user: redirect to do_logout
        print """\
            <!DOCTYPE html>
            <html>
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
            """ % redirect.getRelativeURL("do_logout.py")
        db.close()
        sess.close()
        quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A', 'P')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
    # access denied
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("AccessDenied.py")
    db.close()
    sess.close()
    quit()

#=====================================================================================
# Parameter Validation
#=====================================================================================
# if no id passed, redirect to MaintainVenues.py
if (not form.has_key('id')):
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("MaintainVenues.py")
    sess.close()
    quit()
else:
    ID = form.getfirst('id')

#=====================================================================================
# Page Head
#=====================================================================================
# head of HTML document
print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

#=====================================================================================
# Page Body
#=====================================================================================
# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
else:
    print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a href="MaintainGames.py">Games</a></li>
    <li><a class="active" href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a href="MaintainPlayer.py">Players</a></li>
    <li><a href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

print """<h1>Edit Venues</h1>"""

try:             
    cursor.execute("""SELECT * FROM Venue WHERE VenueID = %s;""", ID)
except:
    print """\
        <p>We could not process your query.<p>"""
        
else:
    if (cursor.rowcount == 1):
        # record found, print form
        VenueDetails = cursor.fetchone()
        print """\
            <form action="do_editVenue.py" name="form" method="post">
            <fieldset>
            <legend>Venue Details</legend>
            <table class="form">
            <tbody>"""
        
        # input for Venue ID
        print"""\
            <tr>
                <td><label for="VenueID">Venue ID</label></td>
                <td><input type="text" name="VenueID"value="%s" readonly></input></td>
            </tr>""" % xstr.xstr(VenueDetails[0])
        
        # input for Venue Name
        print"""\
            <tr>
                <td><label for="VenueName">Venue Name</label></td>
                <td><input type="text" name="VenueName" value="%s"></input></td>
            </tr>""" % xstr.xstr(VenueDetails[1])

        # input for Venue Description
        print """\
            <tr>
                <td><label for="VenueDescription">Venue Description</label></td>
                <td><Textarea name="VenueDescription" style="resize:none" cols=50 rows=5 >%s</Textarea></td>
            </tr>""" % xstr.xstr(VenueDetails[2])

        # input for PowerOutlets
        print """\
            <tr>
                <td><label for="PowerOutlets">Power Outlets</label></td>
                <td><input type="number" name="PowerOutlets" min=0 value="%s" ></input></td>
            </tr>""" % xstr.xstr(VenueDetails[3])

        # input for Lighting Notes
        print """\
            <tr>
                <td><label for="LightingNotes">Lighting Notes</label></td>
                <td><input type="text" name="LightingNotes" value="%s" ></input></td>
            </tr>""" % xstr.xstr(VenueDetails[4])
        
        # dropdown to select the venue supervisor id
        print """\
            <tr>
                <td><label for="VenueSupervisorID">Venue Supervisor (ID:Name)</label></td>
                <td>
                    <select name="VenueSupervisorID" required>
        """
    
        sql = " SELECT PlayerID, FirstName, LastName FROM Player "
        cursor.execute(sql);
        supervisor = cursor.fetchall();
        
        for item in supervisor:
            print """<option value="%s"%s>%s : %s %s</option>""" % (item[0], (" selected " if item[0] == VenueDetails[5] else ""), item[0], item[1], item[2])

        
        print """\
                    </select>
                </td>
            </tr>"""
        
        print """\
            </tbody>
            </table>
            </fieldset>
            <tr><td><input type="submit" value="Submit"></input></td></tr>
            </form>"""
    else:
        print """<p>No record exists.</p>"""



#=====================================================================================
# Footer
#=====================================================================================

print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()
