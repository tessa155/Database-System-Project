# MaintainInstanceRuns.py
# Description: Create new InstanceRun
# Author: Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
    # not logged in: redirect to Login
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("Login.py")
    db.close()
    sess.close()
    quit()    

# logged in: validate user
try:
    cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""", sess.data.get('userName'))          
except:
    # database error
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        # invalid user: redirect to do_logout
        print """\
            <!DOCTYPE html>
            <html>
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
            """ % redirect.getRelativeURL("do_logout.py")
        db.close()
        sess.close()
        quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A', 'P')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
    # access denied
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("AccessDenied.py")
    db.close()
    sess.close()
    quit()

#=====================================================================================
# Page Head
#=====================================================================================
# head of HTML document
print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

#=====================================================================================
# Page Body
#=====================================================================================
# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
else:
    print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a class="active" href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a href="MaintainGames.py">Games</a></li>
    <li><a href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a href="MaintainPlayer.py">Players</a></li>
    <li><a href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

print """<h1>Create Instance Run</h1>"""
        
print """\
    <form action="do_CreateInstanceRun.py" name="form" method="post">
    <fieldset>
    <legend>Instance Run details</legend>
    <table class="form">
    <tbody>"""

# dropdown for supervisor
print """\
    <tr>
        <td><label for="supervisor">Supervisor</label></td>
        <td>
            <select name="SupervisorID" required>"""

sql = """SELECT PlayerID, concat(Supervisor.FirstName, ' \\"', Supervisor.GameHandle, '\\" ', Supervisor.LastName)
         FROM Player AS Supervisor;"""

cursor.execute(sql)

allPlayers = cursor.fetchall()

for player in allPlayers:
    print """<option value="%s">%s</option>""" % (player[0], player[1])

print """\
            </select>
        </td>
    </tr>"""

# input for name 
print"""\
    <tr>
        <td><label for="InstanceRunName">Instance Run Name</label></td>
        <td><input type="text" name="InstanceRunName" required></input></td>
    </tr>"""

# input for recordedtime
print """\
    <tr>
        <td><label for="RecordedTime">Recorded Time</label></td>
        <td><input type="text" name="RecordedTime" required></input></td>
    </tr>"""

# input for category
print """\
    <tr>
        <td><label for="CategoryName">Category</label></td>
        <td><input type="text" name="CategoryName"></input></td>
    </tr>"""

# dropdown for game
print """\
    <tr>
        <td><label for="GameID">Game</label></td>
        <td>
            <select name="GameID" required>"""

sql = """SELECT GameID, GameTitle
         FROM Game;"""

cursor.execute(sql)

allGames = cursor.fetchall()

for game in allGames:
    print """<option value="%s">%s</option>""" % (game[0], game[1])

print """\
            </select>
        </td>
    </tr>"""

# dropdown for venue
print """\
    <tr>
        <td><label for="VenueID">Venue</label></td>
        <td>
            <select name="VenueID">"""

sql = """SELECT VenueID, VenueName
         FROM Venue;"""

cursor.execute(sql)

allVenues = cursor.fetchall()

for venue in allVenues:
    print """<option value="%s">%s</option>""" % (venue[0], venue[1])

print """\
            </select>
        </td>
    </tr>"""

print """\
    </tbody>
    </table>
    </fieldset>
    <tr><td><input type="submit" value="Submit"></input></td></tr>
    </form>"""


#=====================================================================================
# Footer
#=====================================================================================

print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()