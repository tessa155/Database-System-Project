# The libraries we'll need
import sys, cgi, session, redirect, MySQLdb

# ---------------------------------------------------------------------------------------------------------------------
sess = session.Session(expires=20*60, cookie_path='/')
loggedIn = sess.data.get('loggedIn')

# ---------------------------------------------------------------------------------------------------------------------
# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# ---------------------------------------------------------------------------------------------------------------------
# login logic
if loggedIn:
    
    # redirect to home page
    print """\
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="refresh" content="0;url=%s">
    </head>
    <body>
    </body>
    """ % redirect.getRelativeURL("BrowseVideos.py")
    
else:
    form = cgi.FieldStorage()
    if not (form.has_key('username') and form.has_key('password')):
        sess.data['loggedIn'] = 0
    else:
        db = MySQLdb.connect(host="info20003db.eng.unimelb.edu.au", db="info20003g18", passwd="$DeltaSierraP1$", user="info20003g18", port=3306)
        cursor = db.cursor()
        
        if form["password"].value == form["c_password"].value:
            sql_insertUser = """INSERT INTO User VALUES (DEFAULT, %s, %s, 'V'); """
            sql_lastID = """ SELECT UserID FROM User WHERE UserID = last_insert_id();"""
            sql_insertViewer = """ INSERT INTO Viewer VALUES (%s, %s, %s); """
            sql_insertViewerType = """ INSERT INTO ViewerType VALUES (%s, %s); """
            
            try:
                cursor.execute(sql_insertUser, (form["username"].value, form["password"].value));
                cursor.execute(sql_lastID);
                lastID_inserted = cursor.fetchone()
                cursor.execute(sql_insertViewer, (lastID_inserted[0], form["dob"].value, form["email"].value))
                cursor.execute(sql_insertViewerType, (lastID_inserted[0], 'V'))
                db.commit()
                sess.data['loggedIn'] = 1
                sess.data['userName'] = form["username"].value
            except:
                db.rollback()
                print """\
                    <script>
                        alert("Sorry we have encountered an database error, please try again soon");
                    </script>
                """
                
            cursor.close()
            db.close()
            
        else:
            sess.data['loggedIn'] = 0
            print """\
                <script>
                    alert("Password does not match, please try again");
                </script>
            """

    whereToNext = "BrowseVideos.py" if sess.data['loggedIn'] == 1 else "CreateViewerAccount.py"
    
    sess.close()
    
    # redirect to home page or back to the login page
    print """\
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="refresh" content="0;url=%s">
    </head>
    <body>
    </body>
    """ % redirect.getRelativeURL(whereToNext)

