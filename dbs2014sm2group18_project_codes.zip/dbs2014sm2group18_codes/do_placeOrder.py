# Script to place order from cart (viewer subtypes only)
# Aaron Priestley
# 19 10 2014

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()
    
#===========================================
# LOGIN VALIDATION
#===========================================

validUser = False
rdPage = None
message = ""
if sess.data.get('loggedIn'):
    #check that the user is a viewer. if not a viewer, redirect
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName = %s
            """, (MySQLdb.escape_string(sess.data.get('userName'))))
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        if UType == 'V':
            # user is valid viewer, however check that they are a subtype
            cursor.execute ("""
                    SELECT *
                    FROM CrowdFundingViewer
                    WHERE ViewerID = %s
                """, UID)
            rows = []
            CFVrows = cursor.fetchall()
            isCFV = (len(CFVrows) > 0)
            rows += CFVrows
            cursor.execute ("""
                    SELECT *
                    FROM PremiumViewer
                    WHERE ViewerID = %s
                """, UID)
            PVrows = cursor.fetchall()
            isPV = (len(PVrows) > 0)
            rows += PVrows
            if (len(rows) > 0):
                #user is a subtype of viewer, they are valid for this page
                validUser = True
            else:
                rdPage = "BrowseVideos.py"
        else:
            # login detected but not for a viewer, query again to find rdPage
            message = "Redirecting.."
            if UType == 'P':
                # go to a player page
                rdPage = "CreateVideo.py"
            elif UType == 'A':
                # go to an admin page
                rdPage = "MaintainVideo.py"
            else:
                # user of no type found (likely hack), go to logout page
                rdPage = "do_logout.py"
                message = "Logging out.."
    else:
        # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    rdPage = "Login.py"
    message = "Redirecting.."
    
#===========================================
# PAGE DISPLAY AND MAIN CONTENT
#===========================================
        
if not validUser:
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
else:
    form = cgi.FieldStorage()
    if form.has_key('usePerk'):
        #check if perk is being used from checkbox (only submitted if checked)
        usePerk = True
    else:
        usePerk = False
    #-----------------------------------------------------------------------------------------
    #get cart data from cookie
    try:
        cartItms = sess.data.get('cart').split(';')
    except:
        cartItms = []
    validOrder = (len(cartItms) > 0)
    userBalance = 0.0
    totalPrice = 0.0
    # TO DO:
    # get total order price (disregard if flagPerk is False and isPV)
    if (usePerk and isCFV):
        for itm in cartItms:
            cursor.execute("""
                SELECT Price FROM Video
                WHERE VideoID = %s
                       """, itm)
            if cursor.rowcount == 1:
                totalPrice += float(cursor.fetchone()[0])
            else:
                validOrder = False
                break
    if usePerk and isCFV and validOrder:
        cursor.execute("""
        SELECT PerkCreditBalance FROM CrowdFundingViewer
    WHERE ViewerID = %s                       
    """, UID)
        if cursor.rowcount == 1:
            userBalance = float(cursor.fetchone()[0])
        else:
            validOrder = False
        if userBalance < totalPrice:
            validOrder = False
    if not validOrder:
        # if not valid, show error, dump the cart and redirect
        rdPage = "MyOrders.py"
        message = "Invalid Order. Redirecting.."
        print """\
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="refresh" content="0;url=%s">
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>
    %s
    </body>
    """ % (redirect.getRelativeURL(rdPage),message)
    if (usePerk and isCFV and validOrder):
        sql = """UPDATE CrowdFundingViewer
           SET PerkCreditBalance = %s WHERE ViewerID = %s"""
        try:
            cursor.execute(sql, (str(userBalance - totalPrice), UID))
        except:
            db.rollback()
            validOrder = False
    if (validOrder):
        sql = """SELECT DATE(NOW());"""
        try:
            cursor.execute(sql)
            curDate = cursor.fetchone()[0]
        except:
            db.rollback()
            validOrder = False
        if (validOrder):
            sql = """INSERT INTO ViewerOrder VALUES
               (DEFAULT, DATE(%s), %s);"""
            try:
                cursor.execute(sql, (curDate,UID))
                sql = """SELECT LAST_INSERT_ID()"""
                cursor.execute(sql)
                OrdID = cursor.fetchone()[0]
            except:
                db.rollback()
                validOrder = False
        for video in cartItms:
            if not validOrder:
                break
            sql = """INSERT INTO ViewerOrderLine VALUES
               (%s, %s, %s, 'P');"""
            try:
                cursor.execute(sql, (video, OrdID, usePerk))
            except:
                db.rollback()
                validOrder = False
    if (validOrder):
        db.commit()
        message = "Order Placed. Redirecting.." % (cartItms)
    else:
        message = "Order Failed. Redirecting.."
    sess.data['cart'] = None
    rdPage = "MyOrders.py"
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
    #-----------------------------------------------------------------------------------------
db.close()
sess.close()