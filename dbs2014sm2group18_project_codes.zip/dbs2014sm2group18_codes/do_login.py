# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    sess.close()
    quit()

#=====================================================================================
# Login Logic
#=====================================================================================
if (sess.data.get('loggedIn')):
    # logged in: redirect to home
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("BrowseVideos.py")
else:
    if not (form.has_key('username') and form.has_key('password')):
            sess.data['loggedIn'] = 0
            whereToNext = "Login.py"
    else:
        cursor.execute("""SELECT UserID, UserName, UserType
                          FROM User 
                          WHERE UserName = %s AND UserPassword = %s;""", (form.getvalue('username'), form.getvalue('password')))

        if (cursor.rowcount == 1):
            row = cursor.fetchone()
            sess.data['loggedIn'] = 1
            sess.data['userID'] = row[0]
            sess.data['userName'] = row[1]
            sess.data['userType'] = userType = row[2]
            if (userType == 'P' or userType == 'A'):
                whereToNext = "MaintainVideos.py"
            elif (userType == 'V'):
                whereToNext = "BrowseVideos.py"
        else:
            sess.data['loggedIn'] = 0
            whereToNext = "Login.py"
    if not whereToNext == "Login.py":
        message = "Loading.."
    else:
        message = "Redirecting.."
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>
        %s
        </body>""" % (redirect.getRelativeURL(whereToNext), message)



# clean up
db.close()
sess.close()