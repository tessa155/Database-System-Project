public class helloworld{
    public static void main(String[] argv){
        System.out.printf("Hello World!\n");
        System.exit(0);
    }
}