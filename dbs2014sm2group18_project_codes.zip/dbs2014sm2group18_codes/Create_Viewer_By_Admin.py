# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# get the loggedIn info
loggedIn = sess.data.get('loggedIn')

print "%s\nContent-Type: text/html\n" % (sess.cookie)

# redirect to login.py.
if not(loggedIn):
    # redirect to home page
    print """\
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="refresh" content="0;url=%s">
    </head>
    <body>
    </body>
    """ % redirect.getRelativeURL("Login.py")

else:
    # Get a DB connection
    try:
        db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
        cursor = db.cursor()
    except:
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("dberror.py")
        sess.close()
        quit()
        
        
    userName = sess.data.get('userName');
    # Check if this user is admin or not
    sql = """
        SELECT UserType
        FROM User
        WHERE UserName = '%s'
        """ % userName
    cursor.execute(sql)
    row = cursor.fetchone()
    
    #if not admin, go to error msg page(make it later)
    if row[0] != 'A':
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("AccessDenied.py")
        sess.close()
        cursor.close()
        quit()

#----------permission checked-----------------#

                   
                   
                   
# head of HTML document
print """\
    <!doctype html>
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""


# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a href="MaintainGames.py">Games</a></li>
    <li><a href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a href="MaintainPlayer.py">Players</a></li>
    <li><a class="active" href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#-----------------------------------------------------------------------------------------
attrAddress = ['StreetAddressLine1', 'StreetAddressLine2', 'MinorMuniciplity',
               'MajorMuniciplity', 'GoverningDistrict', 'PostCode', 'Country'] 


form = cgi.FieldStorage()
if not(form.has_key('type')) :
    print """
      <!-- Place for page navigation links -->
      <div id="PageLinks" class="PageBox">
          <h2>Choose the type of a viewer</h2>
          <form method = 'get' action = 'Create_Viewer_By_Admin.py'>
              <input type="radio" name="type" value="CrowdFunding">CrowdFunding Viewer<br>
              <input type="radio" name="type" value="Premium">Premium Viewer<br>
              <input type = "radio" name = "type" value= "Both">Both<br><br>
              <input type="submit" value="Submit">
          </form>
      </div>
    """
else:
    sql_c = """<tr><td>First Name</td><td><input type="text" name="FirstName" required></td></tr>
               <tr><td>Last Name</td><td><input type="text" name="LastName" required></td></tr>
               <tr><td>Donation</td><td><input type="text" name="Donation" required></td></tr>"""
    
    sql_p = '<tr><td>Purchase a subscription for</td><td><input type="text" name="subscription" required> &nbsp;weeks</td></tr>'
    
    sql_p_a = "<tr><td><p>- Address information</p></td><td></td></tr>"
    
    i = 0
    for ele in attrAddress:
        sql_p_a+= "<tr>"
        if(i == 1 or i == 2):
            sql_p_a+= '<td>%s</td><td><input type="text" name="%s" size="40" value=""/></td>' %(attrAddress[i],attrAddress[i])
        else:
            sql_p_a+= '<td>%s</td><td><input type="text" name="%s" size="40" value="" required/></td>' %(attrAddress[i],attrAddress[i])
        i+=1;
        sql_p_a+= "</tr>"    
    
    
    
    sql_s = """</tbody></table>
               </fieldset>
               <br>
               <input type = "submit" value = "Register"> 
                 
               </form>"""
    
    print """<div id="SearchResults" class="PageBox">                
            <h2>Register Viewer</h2>
            
            <form method = 'post' action="do_create_viewer_by_admin.py?type=%s" name = 'form'>
            <fieldset>
            <legend>Viewer Details</legend>
            <table class = 'form'>
            <tbody>
                <tr><td><p>- General information</p></td><td></td></tr>
                <tr><td>Username</td><td><input type="text" name="UserName" required></td></tr>
                <tr><td>Password</td><td><input type="password" name="UserPassword" required></td></tr>
                <tr><td>Date of Birth(yyyy-mm-dd)</td><td><input type="text" name="DateOfBirth" required></td></tr>
                <tr><td>Email</td><td><input type="text" name="Email" required></td></tr>""" % form['type'].value
    
    if(form['type'].value=='CrowdFunding'):
        # put donation value in TotalAmountDonated and calculate the balance with it.
        print sql_c
        
    elif (form['type'].value == 'Premium'):
        print sql_p+sql_p_a   
    else:
        print sql_c+sql_p+sql_p_a
        
    print sql_s                 
print "</div>"
        
#-----------------------------------------------------------------------------------------

# footer + end of document
print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
cursor.close()
db.commit()
db.close()
sess.close()        



