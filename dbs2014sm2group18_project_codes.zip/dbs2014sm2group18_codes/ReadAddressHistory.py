# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# get the loggedIn info
loggedIn = sess.data.get('loggedIn')

print "%s\nContent-Type: text/html\n" % (sess.cookie)

# redirect to login.py.
if not(loggedIn):
    # redirect to home page
    print """\
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="refresh" content="0;url=%s">
    </head>
    <body>
    </body>
    """ % redirect.getRelativeURL("Login.py")

else:
    # Get a DB connection
    try:
        db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
        cursor = db.cursor()
    except:
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("dberror.py")
        sess.close()
        quit()
        
        
    userName = sess.data.get('userName');
    # Check if this user is admin or not
    sql = """
        SELECT UserType
        FROM User
        WHERE UserName = '%s'
        """ % userName
    cursor.execute(sql)
    row = cursor.fetchone()
    
    #if not admin, go to error msg page(make it later)
    if row[0] != 'A':
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("AccessDenied.py")
        sess.close()
        cursor.close()
        quit()

#----------permission checked-----------------#

                   
                   
                   
# head of HTML document
print """\
    <!doctype html>
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""


# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a href="MaintainGames.py">Games</a></li>
    <li><a href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a href="MaintainPlayers.py">Players</a></li>
    <li><a class="active" href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#-----------------------------------------------------------------------------------------

form = cgi.FieldStorage()
attrAddress = ['StreetAddressLine1', 'StreetAddressLine2', 'MinorMuniciplity',
               'MajorMuniciplity', 'GoverningDistrict', 'PostCode', 'Country']

if not(form.has_key('number')) :
    userID = form['userID'].value
    sql="""SELECT * FROM Viewer
           INNER JOIN ViewerAddress
           ON Viewer.ViewerID = ViewerAddress.ViewerID
           INNER JOIN Address
           ON ViewerAddress.AddressID = Address.AddressID
           WHERE Viewer.ViewerID = %s
           AND EndDate IS NOT NULL
           ORDER BY StartDate""" %userID
    
    cursor.execute(sql)
    result = cursor.fetchall()

    
    if(not result):
        print """
        <h2>There is no any address history</h2>
        <a href = 'ReadUpdateViewerByAdmin.py?userID=%s'>Go back to the last page</a>""" %(userID)

        
    else:
        print """
          <h2>Choose the address number(arranged in time order)</h2>
          <form method = post action='ReadAddressHistory.py?userID=%s' name='form'>""" %(userID)
    
    
        for i in range(cursor.rowcount):
            print "<input type='radio' name='number' value='%s'>%s<br>" %(str(i), "Address "+str(i+1))
        print """<br><input type="submit" value="Submit">
              </form>
        """
else:
    userID = form['userID'].value
    addressNum = form['number'].value
    
    print """<div id="SearchResults" class="PageBox">            
             <h2>Address History</h2>
             <hr>"""

    sql = """SELECT StreetAddressLine1, StreetAddressLine2, MinorMuniciplity,
            MajorMuniciplity, GoverningDistrict, PostCode, Country FROM Viewer
            INNER JOIN ViewerAddress
            ON Viewer.ViewerID = ViewerAddress.ViewerID
            INNER JOIN Address
            ON ViewerAddress.AddressID = Address.AddressID
            WHERE Viewer.ViewerID = %s
            AND EndDate IS NOT NULL
            ORDER BY StartDate; """ %(userID)
    
    cursor.execute(sql)
    result = cursor.fetchall()
    print "<form method = post action = 'do_update_address_history.py?userID=%s&addressNum=%s' name='form'>" %(userID, addressNum)
    print """<fieldset>
        <legend>Address Detail</legend>
        <table class = 'form'>
        <tbody>"""

    i = 0
    for ele in result[int(addressNum)]:
        print "<tr>"
        if(i == 1 or i == 2):
            if(ele == None):
                print '<td>%s</td><td><input type="text" name="%s" size="40" value=""/></td>' %(attrAddress[i],attrAddress[i])
            else:
                print '<td>%s</td><td><input type="text" name="%s" size="40" value="%s"/></td>' %(attrAddress[i],attrAddress[i], ele)
        else:
            print '<td>%s</td><td><input type="text" name="%s" size="40" value="%s" required/></td>' %(attrAddress[i],attrAddress[i],ele)
        print "</tr>"
        i+=1;
                
    print "</tbody></table>"
    print "</fieldset>"
    print '<br><input type="submit" value = "Update"/>'
    print '</form>'

#--------------------------------------------------------


# footer + end of document
print """\
    </div>
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.commit()
cursor.close()
db.close()
sess.close()








