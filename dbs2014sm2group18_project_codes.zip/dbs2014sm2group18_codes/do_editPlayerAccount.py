# Script to update player account (player-side)
# Aaron Priestley
# 19 10 2014

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()
    
#===========================================
# LOGIN VALIDATION
#===========================================

validUser = False
rdPage = None
message = ""
if sess.data.get('loggedIn'):
    #check that the user is a viewer. if not a viewer, redirect
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName = %s
            """, sess.data.get('userName'))
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        if UType == 'V':
        # go to a player page
            rdPage = "MyViewerAccount.py"
            message = "Redirecting.."
        elif UType == 'P':
            # continue showing this page to the player
            validUser == True
        elif UType == 'A':
            # go to an admin page
            rdPage = "MaintainVideo.py"
            message = "Redirecting.."
        else:
            # user of no type found (likely hack), go to logout page
            rdPage = "do_logout.py"
            message = "Logging out.."
    else:
        # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    rdPage = "Login.py"
    message = "Redirecting.."
    
#===========================================
# PAGE DISPLAY AND MAIN CONTENT
#===========================================
        
if not validUser:
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
else:
    form = cgi.FieldStorage()
    #-----------------------------------------------------------------------------------------
    # preload player information to prefill form
    sql = """ SELECT FirstName, LastName, Role, ProfileDescrition,
    Email, GameHandle, Phone, VoIP
    FROM Player WHERE 
        PlayerID = %s"""
    cursor.execute(sql, UID)
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        fname = row[0]
        lname = row[1]
        role = row[2]
        pdesc = row[3]
        email = row[4]
        ghandle = row[5]
        phone = row[6]
    # get supervisor information if any
    sql = """ SELECT FirstName, LastName
    FROM Player p, Player s WHERE 
        s.PlayerID = p.SupervisorID AND
        p.PlayerID = %s"""
    cursor.execute(sql, UID)
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        sup_fname = row[0]
        sup_lname = row[1]
    else:
        sup_fname = ""
        sup_lname = ""
    sql = """ SELECT Address.StreetAddressLine1, Address.StreetAddressLine2,
    Address.MinorMuniciplity,
    Address.MajorMuniciplity, Address.GoverningDistrict, Address.PostCode,
    Address.Country FROM Address NATURAL JOIN PlayerAddress
    WHERE PlayerID = %s"""
    cursor.execute(sql, UID)
    p_addr_str1 = None
    p_addr_str2 = None
    p_addr_minMun = None
    p_addr_majMun = None
    p_add_govD = None
    p_add_postalA = None
    p_add_country = None
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        p_addr_str1 = row[0]
        p_addr_str2 = row[1]
        p_addr_minMun = row[2]
        p_addr_majMun = row[3]
        p_add_govD = row[4]
        p_add_postalA = row[5]
        p_add_country = row[6]
    validUpdate = True
    # read form input
    new_pdesc = None
    if (form.has_key('pdesc'):
        new_pdesc = form.getValue('pdesc')
    else:
        new_pdesc = pdesc
    new_ghandle = None
    if (form.has_key('ghandle')):
        new_phandle = form.getValue('ghandle')
    else:
        new_phandle = phandle
    #get new address
    new_p_addr_str1 = form.getvalue('p_addr_str1')
    new_p_addr_str2 = form.getvalue('p_addr_str2')
    new_p_addr_minMun = form.getvalue('p_addr_minMun')
    new_p_addr_majMun = form.getvalue('p_addr_majMun')
    new_p_addr_govD = form.getvalue('p_addr_govD')
    new_p_addr_postalA = form.getvalue('p_addr_postalA')
    new_p_addr_country = form.getvalue('p_addr_country')
    # validate form input
    cursor.execute(""" SELECT GameHandle FROM Player 
    WHERE GameHandle = %s AND PlayerID != %s""", new_ghandle, UID)
    rows = cursor.fetchall()
    if (len(rows) > 0):
        #another user has the game handle, abort updating the form
        validUpdate = False
        message = "Update Failed (invalid game handle). Redirecting.."
    if (validUpdate):
        # update the form
        try:
            cursor.execute(""" UPDATE TABLE Player
        SET GameHandle = %s, ProfileDescription = %s WHERE
        PlayerID = %s""", (new_ghandle, 
                           new_PlayerDescription, UID))
            db.commit()
        except:
            db.rollback()
            validUpdate = False
    if (validUpdate):
        #update player address
        try:
            params = ('DEFAULT', new_p_addr_str1, new_p_addr_str2, 
            new_p_addr_minMun, new_p_addr_govD, new_p_addr_postalA, 
            new_p_addr_country)
            #check if duplicate value
            cursor.execute(""" SELECT * FROM Address WHERE
            StreetAddressLine1 = %s AND
            StreetAddressLine2 = %s AND
            MinorMuniciplity = %s AND
            GoverningDistrict = %s AND
            Country = %s""" % (MySQLdb.escape_string(new_p_addr_str1), 
                               MySQLdb.escape_string(new_p_addr_str2), 
            MySQLdb.escape_string(new_p_addr_minMun), MySQLdb.escape_string(new_p_addr_govD), 
                               MySQLdb.escape_string(new_p_addr_postalA), 
            MySQLdb.escape_string(new_p_addr_country)))
            dupRows = cursor.fetchall()
            if (cursor.rowcount > 0):
                duplicate = True
            if not duplicate:
                insertSQL = "INSERT INTO Address VALUES %s" % (params)
            else:
                insertSQL = ""
            cursor.execute(""" UPDATE PlayerAddress SET EndDate = DATE(now())
            WHERE PlayerID = %s AND EndDate IS NULL;
        %s;
        SET @AID = LAST_INSERT_ID();
        SELECT @AID;
        """ % (UID, params))
            AID = int(cursor.fetchone[0])
            cursor.execute(""" INSERT INTO TABLE PlayerAddress  VALUES
            (%s,%s,DATE(NOW()),NULL)
        """, UID, AID)
            db.commit()
        except:
            db.rollback()
            validUpdate = False;
    #redirect the user back to the cart page
    rdPage = "MyPlayerAccount.py"
    if validUpdate:
        message = "Update Successful. Redirecting.."
    else:
        message = "Update Failed. Redirecting.."
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
    #-----------------------------------------------------------------------------------------
db.close()
sess.close()