# Script to edit viewer account (viewer-side)
# Aaron Priestley
# 19 10 2014

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()
    
#===========================================
# LOGIN VALIDATION
#===========================================

validUser = False
rdPage = None
message = ""
if sess.data.get('loggedIn'):
    #check that the user is a viewer. if not a viewer, redirect
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName = %s
            """, (MySQLdb.escape_string(sess.data.get('userName'))))
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        if UType == 'V':
            # user is valid viewer, however check that they are a subtype
            cursor.execute ("""
                    SELECT *
                    FROM CrowdFundingViewer
                    WHERE ViewerID = %s
                """, UID)
            rows = []
            CFVrows = cursor.fetchall()
            isCFV = (len(CFVrows) > 0)
            rows += CFVrows
            cursor.execute ("""
                    SELECT *
                    FROM PremiumViewer
                    WHERE ViewerID = %s
                """, UID)
            PVrows = cursor.fetchall()
            isPV = (len(PVrows) > 0)
            rows += PVrows
            validUser = True
        else:
            # login detected but not for a viewer, query again to find rdPage
            message = "Redirecting.."
            if UType == 'P':
                # go to a player page
                rdPage = "CreateVideo.py"
            elif UType == 'A':
                # go to an admin page
                rdPage = "MaintainVideo.py"
            else:
                # user of no type found (likely hack), go to logout page
                rdPage = "do_logout.py"
                message = "Logging out.."
    else:
        # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    rdPage = "Login.py"
    message = "Redirecting.."
    
#===========================================
# PAGE DISPLAY AND MAIN CONTENT
#===========================================
        
if not validUser:
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
else:
    form = cgi.FieldStorage()
    #-----------------------------------------------------------------------------------------
    # preload player information to prefill form
    sql = """ SELECT DateOfBirth, Email
    FROM Viewer WHERE 
        ViewerID = %s"""
    cursor.execute(sql, UID)
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        DOB = row[0]
        email = row[1]
    if (isPV):
        sql = """ SELECT RenewalDate
    FROM PremiumViewer WHERE 
        ViewerID = %s"""
        cursor.execute(sql, UID)
        if cursor.rowcount == 1:
            row = cursor.fetchone()
            renewDate = row[0]
    if (isCFV):
        sql = """ SELECT FirstName, LastName, Balance, TotalAmountDonated
    FROM CrowdFundingViewer WHERE 
        ViewerID = %s"""
        cursor.execute(sql, UID)
        if cursor.rowcount == 1:
            row = cursor.fetchone()
            fname = row[0]
            lname = row[1]
            balance = row[2]
            totDonated = row[3]
    #get new address
    new_v_addr_str1 = form.getvalue('v_addr_str1')
    new_v_addr_str2 = form.getvalue('v_addr_str2')
    new_v_addr_minMun = form.getvalue('v_addr_minMun')
    new_v_addr_majMun = form.getvalue('v_addr_majMun')
    new_v_addr_govD = form.getvalue('v_addr_govD')
    new_v_addr_postalA = form.getvalue('v_addr_postalA')
    new_v_addr_country = form.getvalue('v_addr_country')
    new_email = form.getvalue('email')
    new_DOB = form.getvalue('birthDate')
    validUpdate = True
    if (validUpdate):
        # update the form
        try:
            cursor.execute("""UPDATE Viewer
        SET DateOfBirth = %s, Email = %s WHERE
        ViewerID = %s;""", (new_DOB, new_email, UID))
            message = "Update Successful. Redirecting.."
            db.commit()
        except:
            db.rollback()
            validUpdate = False
            message = "Update Failed. Redirecting.."
    if (validUpdate and isPV):
        #update player address
        try:
            params = ('DEFAULT', new_v_addr_str1, new_v_addr_str2, 
            new_v_addr_minMun, new_v_addr_govD, new_v_addr_postalA, 
            new_v_addr_country)
            duplicate = False
            #check if duplicate value
            cursor.execute(""" SELECT * FROM Address WHERE
            StreetAddressLine1 = %s AND
            StreetAddressLine2 = %s AND
            MinorMuniciplaity = %s AND
            GoverningDistrict = %s AND
            Country = %s;""", (MySQLdb.escape_string(new_v_addr_str1), 
                               MySQLdb.escape_string(new_v_addr_str2), 
            MySQLdb.escape_string(new_v_addr_minMun), MySQLdb.escape_string(new_v_addr_govD), 
                               MySQLdb.escape_string(new_v_addr_postalA), 
            MySQLdb.escape_string(new_v_addr_country)))
            dupRows = cursor.fetchall()
            if (cursor.rowcount > 0):
                duplicate = True
            if not duplicate:
                insertSQL = "INSERT INTO Address VALUES %s;" % (params)
            else:
                insertSQL = ""
            cursor.execute(""" UPDATE ViewerAddress SET EndDate = DATE(now())
            WHERE ViewerID = %s AND EndDate IS NULL;
        %s
        SET @AID = LAST_INSERT_ID();
        SELECT @AID;
        """ % (UID, insertSQL))
            AID = int(cursor.fetchone[0])
            cursor.execute(""" INSERT INTO ViewerAddress  VALUES
            (%s,%s,DATE(NOW()),NULL)
        """ % (UID, AID))
        except:
            db.rollback()
            validUpdate = False
            message = "Update Failed. Redirecting.."
    #redirect the user back to the cart page
    rdPage = "MyViewerAccount.py"
    if (validUpdate):
        db.commit()
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
db.close()
sess.close()