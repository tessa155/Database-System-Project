# AccessDenied.py
# Description: Redirect here when access denied
# Author: Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# header area
print """\
    <!-- Header with company logo -->
    <div style="margin:auto;padding:100px 0;text-align:center;" id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    </a>
    <h1>Access Denied</h1>
    <p>We're sorry, but you don't have permission to view this content.</p>
    </div>"""
