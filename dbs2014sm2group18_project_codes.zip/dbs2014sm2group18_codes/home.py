# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

whereToNext = "BrowseVideos.py"

print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>
        Redirecting..
        </body>""" % redirect.getRelativeURL(whereToNext)
