# Script to browse all videos available
# Aaron Priestley
# 19 10 2014

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()
    
#===========================================
# LOGIN VALIDATION
#===========================================

# check for login status and details
validUser = False
rdPage = None
message = ""
isCFV = False
isPV = False
if sess.data.get('loggedIn'):
    #check that the user is a viewer
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName = %s
            """, (MySQLdb.escape_string(sess.data.get('userName'))))
    if cursor.rowcount == 1:
        # user is valid viewer, but make checks about subtypes (for later)
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        if (UType == 'V'):
            cursor.execute ("""
                    SELECT *
                    FROM CrowdFundingViewer
                    WHERE ViewerID = %s
                """, (UID))
            rows = []
            CFVrows = cursor.fetchall()
            isCFV = (len(CFVrows) > 0)
            rows += CFVrows
            cursor.execute ("""
                    SELECT *
                    FROM PremiumViewer
                    WHERE ViewerID = %s
                """, (UID))
            PVrows = cursor.fetchall()
            isPV = (len(PVrows) > 0)
            rows += PVrows
            validUser = True
        else:
            # login detected but not for a viewer, query again to find rdPage
            message = "Redirecting.."
            if UType == 'P':
                # go to a player page
                rdPage = "CreateVideo.py"
            elif UType == 'A':
                # go to an admin page
                rdPage = "MaintainVideos.py"
            else:
                # user of no type found (likely hack), go to logout page
                rdPage = "do_logout.py"
                message = "Logging out.."
    else:
         # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    # no login detected, redirect to login page
    UID = None
    rdPage = "Login.py"
    message = "Redirecting.."

#===========================================
# PAGE DISPLAY AND MAIN CONTENT
#===========================================
        
# redirect if not public or viewer
if (sess.data.get('loggedIn') and not validUser):
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
else:    
    # head of HTML document
    form = cgi.FieldStorage()
    print """\
        <!doctype html>
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>WWAG</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>"""
    # top bar and accountpanel
    if (isCFV):
        cursor.execute(""" SELECT FirstName FROM CrowdFundingViewer WHERE ViewerID = %s"""
                       , (UID))
        FName = cursor.fetchone()[0]
    print """\
        <!-- Top bar with account panel (my account | logout) -->
        <div id="TopBar">
        <div id="AccountPanel">"""
    if sess.data.get('loggedIn'):
        if not isCFV:
            print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
        else:
            print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % FName
    else:
        print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""
    print """\
        </div>
        </div>"""
    # header area
    print """\
        <!-- Header with company logo -->
        <div id="Header">
        <a href="home.py" id="Logo">
        <img src="images/Logo.svg" alt="Logo"/>
        <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
        </a>
        </div>"""
    # main nav
    print """\
        <!-- Main navigation bar -->
        <div id="TopNav">
        <ul>
        <li><a class="active" href="BrowseVideos.py">Videos</a></li>
        <li><a href="Players.py">Players</a></li>
        <li><a href="Games.py">Games</a></li>
        <li><a href="Venues.py">Venues</a></li>
        <li><a href="Equipment.py">Equipment</a></li>
        <li><a href="About.py">About</a></li>
        </ul>
        </div>"""
    # page area
    print """\
        <!-- The main body section of the page -->
        <div id="PageWrapper">"""
    #-----------------------------------------------------------------------------------------
    print """<h1>Browse Videos</h1>"""
    #get cart data from cookie
    try:
        cartItms = sess.data.get('cart').split(';')
    except:
        cartItms = []
    #get previous order data for user if CFV or PV
    CFVOrders = []
    PVOrders = []
    if isCFV or isPV:
        cursor.execute("""SELECT Video.VideoID,
    ViewerOrderLine.ViewedStatus,
    ViewerOrderLine.FlagPerk
    FROM Video NATURAL JOIN ViewerOrderLine
    NATURAL JOIN ViewerOrder
    WHERE
    ViewerOrder.ViewerID = %s
    """, UID)
        if cursor.rowcount > 0:
            rows = cursor.fetchall()
        else:
            rows = []
        for item in rows:
            if item[2] == True:
                CFVOrders.append(item)
            else:
                PVOrders.append(item)
    # get sort information
    sortTerm = form.getvalue('sortTerm')
    if sortTerm == None:
        sortTerm = "InstanceName"
    if form.getvalue('sortDir'):
        sortDir = "DESC"
    else:
        sortDir = "ASC"
    # sorting form
    print """
    <form id = "browsesortform">
        Sort by: <select name = "sortTerm">
            <option value = "InstanceName">Instance Name</option>
            <option value = "Category">Category</option>
    <option value = "VideoType">Video Type</option>
    <option value = "GameTitle">Game</option>
    <option value = "Genre">Genre</option>
    <option value = "GameRating">Rating</option>
    <option value = "Price">Price</option>
        </select>
        Reverse Order: <input name = "sortDir" type = "checkbox" value = "off"/>
        <input type = "submit" value = "Sort"/>
    </form>
    """
    # get video details
    cursor.execute("""
    SELECT DISTINCT Video.VideoType,
    InstanceRun.InstanceRunName AS InstanceName, 
    InstanceRun.CategoryName AS Category,
    Video.VideoType As VideoType,
    Game.GameTitle As GameTitle,
    Game.Genre As Genre, 
    Game.GameID As GameID,
    Game.StarRating As GameRating,
    Video.VideoID As ID,
    Video.Price As Price,
    ViewerOrderLine.ViewedStatus As Viewed,
    ViewerOrderLine.FlagPerk As Perk,
    Video.URL As VideoURL
    FROM Video LEFT JOIN InstanceRun ON Video.InstanceRunID = InstanceRun.InstanceRunID
    LEFT JOIN ViewerOrderLine ON Video.VideoID = ViewerOrderLine.VideoID
    INNER JOIN Game ON InstanceRun.GameID = Game.GameID GROUP BY Video.VideoID
    ORDER BY %s %s;
    """ %  (sortTerm, sortDir))
    if cursor.rowcount == 0:
        # no videos to show
        print """No videos to show
        """
    else:
        videodata = cursor.fetchall()
        if (isCFV or isPV):
            print """<form name = "browseform" action = "do_addToCart.py" method = "post">"""
        print "<table>"
        print """<tr>
        <th>Instance Name</th>
        <th>Category</th>
        <th>Video Type</th>
        <th>Game</th>
        <th>Genre</th>
        <th>Rating</th>
        <th>Status</th>
        <th>Price</th>
        <th>Actions</th>
        </tr>
        """
        # print videos one by one in a table
        for video in videodata:
            print "<tr>"
            for i in range(1,len(video)-3):
                # check status of item (in order, cart or purchased, or show 
                # price)
                if i == 9:
                    # check if premium item
                    if video[9] == None or float(video[9]) == 0:
                        # standard item
                        print "<td>Free</td>"
                        print ("""<td><a href = "%s?viewVid=%s">View</a></td>""" % 
                               ("do_viewVideo.py", video[8]))
                    else:
                        # check if item has been purchased
                        isPurch = False
                        for j in range(len(CFVOrders)):
                            if video[8] == CFVOrders[j][0]:
                                isPurch = True
                                print ("""<td>Owned</td><td><a href = "%s?viewVid=%s">View</a></td>""" % 
                                    ("do_viewVideo.py", video[8]))
                                i+=1
                        # check if brought under subscription
                        if (not isPurch):
                            for j in range(len(PVOrders)):
                                if video[8] == PVOrders[j][0]:
                                    isPurch = True
                                    print ("""<td>Subscribed</td><td><a href = "%s?viewVid=%s">View</a></td>""" % 
                                            ("do_viewVideo.py", video[8]))
                                    i+=1
                        # display appropriate items (depending on login and usertype)
                        if (not isPurch):
                            if (isCFV or isPV):
                                print "<td>%s</td>" % (video[9])
                                if (str(video[8]) in cartItms):
                                    print ("""<td><a href = "%s">In cart</a></td>""" % ("MyCart.py"))
                                else:
                                    print ("""<td>Add to cart: 
                                    <input name = "%s" type = "checkbox" value = "off"/></td>""" % 
                                        (video[8]))
                                i+=1
                            else:
                                if (sess.data.get('loggedIn')):
                                    print "<td>%s</td>" % (video[9])
                                    print ("""<td>Update Account</td>""")
                                    i+=1
                                else:
                                    print "<td>%s</td>" % (video[9])
                                    print ("""<td><a href = "%s">Create Account</a></td>""" % 
                                ("CreateViewerAccount.py"))
                elif (i == 4):
                    print """<td><a href=Games.py#%s>%s</a></td>""" % (video[6], video[4])
                elif (i == 8):
                    # print view status
                    viewStatus = ""
                    if video[10] == 'V':
                        if UID != None and (isCFV or isPV):
                            cursor.execute(""" SELECT ViewerOrderLine.ViewedStatus FROM ViewerOrderLine 
                                       NATURAL JOIN ViewerOrder NATURAL JOIN Video
                                       WHERE ViewerOrder.ViewerID = %s AND Video.VideoID = %s""", 
                                       (UID, video[8]))
                            try:
                                vType = cursor.fetchone()[0]
                                viewStatus = "Viewed" if vType == 'V' else "Pending"
                            except:
                                vType = "Ready for Purchase"
                                viewStatus = vType
                        else:
                            viewStatus = "Paid Members Only"
                    elif video[9] == None or float(video[9]) == 0:
                        viewStatus = "Public"
                    else:
                        if UID != None and (isCFV or isPV):
                            cursor.execute(""" SELECT ViewerOrderLine.ViewedStatus FROM ViewerOrderLine 
                                       NATURAL JOIN ViewerOrder NATURAL JOIN Video
                                       WHERE ViewerOrder.ViewerID = %s AND Video.VideoID = %s""", 
                                       (UID, video[8]))
                            try:
                                vType = cursor.fetchone()[0]
                                viewStatus = "Viewed" if vType == 'V' else "Pending"
                            except:
                                vType = "Ready for Purchase"
                                viewStatus = vType
                        else:
                            viewStatus = "Paid Members Only"
                    print ("""<td>%s</td>""" % (viewStatus))
                elif (i==6 or i == 9 or i == 11):
                    continue 
                elif (i == 1):
                    print ("""<td><a href = "%s?id=%s">%s</a></td>""" % ("Video.py", video[8], 
                           video[i]))
                else:
                    print ("""<td>%s</td>""" % (video[i]))
            print "</tr>"
        print "</table>"
        if (isCFV or isPV):
            print """<input name = "addToCart" type = "submit" value = "Add to cart"/>
        </form><br/>"""
        if (isCFV or isPV):
            print """ <a href = "%s">View Cart</a>, <a href = "%s">Clear Cart</a><br/>
            <a href = "%s">View Orders</a>""" % ("MyCart.py","do_wipeCart.py","MyOrders.py")
    #-----------------------------------------------------------------------------------------
    # footer + end of document
    print """\
        </div>
        <!-- Footer area with copyright and links -->
        <div id="Footer">
        <div id="FooterContent" class="container">
        <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
        </div>
        </div>        
        </body>
        </html>"""

# clean up
db.close()
sess.close()