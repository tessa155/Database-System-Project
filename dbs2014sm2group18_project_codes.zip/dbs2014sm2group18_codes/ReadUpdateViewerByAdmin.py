# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# get the loggedIn info
loggedIn = sess.data.get('loggedIn')

print "%s\nContent-Type: text/html\n" % (sess.cookie)

# redirect to login.py.
if not(loggedIn):
    # redirect to home page
    print """\
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="refresh" content="0;url=%s">
    </head>
    <body>
    </body>
    """ % redirect.getRelativeURL("Login.py")

else:
    # Get a DB connection
    try:
        db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
        cursor = db.cursor()
    except:
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("dberror.py")
        sess.close()
        quit()
        
        
    userName = sess.data.get('userName');
    # Check if this user is admin or not
    sql = """
        SELECT UserType
        FROM User
        WHERE UserName = '%s'
        """ % userName
    cursor.execute(sql)
    row = cursor.fetchone()
    
    #if not admin, go to error msg page(make it later)
    if row[0] != 'A':
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("AccessDenied.py")
        sess.close()
        cursor.close()
        quit()

#----------permission checked-----------------#

                   
                   
                   
# head of HTML document
print """\
    <!doctype html>
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""


# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a href="MaintainGames.py">Games</a></li>
    <li><a href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a href="MaintainPlayer.py">Players</a></li>
    <li><a class="active" href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#-----------------------------------------------------------------------------------------

form = cgi.FieldStorage()
userID = form['userID'].value

attr = ["UserID", "UserName", "UserPassword", "DateOfBirth", "Email"]
attr_C = ["FirstName", "LastName", "PerkCreditBalance", "TotalAmountDonated"]
attrAddress = ['StreetAddressLine1', 'StreetAddressLine2', 'MinorMuniciplity',
               'MajorMuniciplity', 'GoverningDistrict', 'PostCode', 'Country']               



sql = """SELECT UserID, UserName, UserPassword, DateOfBirth, Email
             FROM User
             INNER JOIN Viewer
             ON User.UserID = Viewer.ViewerID
             WHERE UserID = %s """ %(userID)


print """<div id="SearchResults" class="PageBox">
                
             <h2>Viewer Information</h2>
             <hr>"""

cursor.execute(sql)
result = cursor.fetchone()


# show the information
print "<p style='text-align:right'><a href = 'do_delete_viewer.py?userID=%s'>Delete this viewer</a></p>" % userID
print "<form method = post action = 'do_update_viewer.py?userID=%s' name='form'>" %(userID)
print """<fieldset>
    <legend>Viewer Details</legend>
    <table class = 'form'>
    <tbody>"""
print "<tr><td><p>- General information</p></td><td></td></tr>" 


i = 0
for ele in result:
    print "<tr>"
    
    if(attr[i] == 'UserID' or attr[i] == 'UserName'):
        print '<td>%s</td><td><input type="text" name="%s" size="40" value="%s" required readonly/></td>' %(attr[i], attr[i],ele)
    else:
        print '<td>%s</td><td><input type="text" name="%s" size="40" value="%s" required /></td>' %(attr[i], attr[i],ele)
        
    print "</tr>"
    i+=1
    

user_cfv = False;
user_pv = False;
    
# check if the viewer is crowdfunding viewer
sql = """SELECT FirstName, LastName, PerkCreditBalance, TotalAmountDonated
            FROM Viewer INNER JOIN CrowdFundingViewer
            ON Viewer.ViewerID = CrowdFundingViewer.ViewerID
            WHERE Viewer.ViewerID = %s """ %userID
cursor.execute(sql)
result = cursor.fetchone()

if (result):
    user_cfv = True;
    i = 0
    for ele in result:
        print "<tr>"
        print '<td>%s</td><td><input type="text" name="%s" size="40" value="%s" required/></td>' %(attr_C[i],attr_C[i],ele)
        print "</tr>"
        i+=1
    
# check if the viewer if premium viewer
sql = """SELECT RenewalDate
            FROM Viewer INNER JOIN PremiumViewer
            ON Viewer.ViewerID = PremiumViewer.ViewerID
            WHERE Viewer.ViewerID = %s""" %userID

cursor.execute(sql)
result = cursor.fetchone()

if (result):
    user_pv = True;
    print "<tr>"
    print '<td>%s</td><td><input type="text" name="%s" size="40" value="%s" required/></td>' %("RenewalDate (yyyy-mm-dd)","RenewalDate", result[0])
    print "</tr>"
    
if (result):
    print "<tr><td><p>- Address information</p></td><td><p style='text-align:right'><a href = 'ReadAddressHistory.py?userID=%s'>Read Address History</a></p></td></tr>"  % userID
    sql = """SELECT StreetAddressLine1, StreetAddressLine2, MinorMuniciplity,
              MajorMuniciplity, GoverningDistrict, PostCode, Country FROM Viewer
            INNER JOIN ViewerAddress
            ON Viewer.ViewerID = ViewerAddress.ViewerID
            INNER JOIN Address
            ON ViewerAddress.AddressID = Address.AddressID 
            WHERE ViewerAddress.EndDate IS NULL
            AND Viewer.ViewerID = %s; """ %(userID)  
    
    cursor.execute(sql)
    result = cursor.fetchone()
    i = 0
    for ele in result:
        print "<tr>"
        if(i == 1 or i == 2):
            if(ele == None):
                print '<td>%s</td><td><input type="text" name="%s" size="40" value=""/></td>' %(attrAddress[i],attrAddress[i])
            else:
                print '<td>%s</td><td><input type="text" name="%s" size="40" value="%s"/></td>' %(attrAddress[i],attrAddress[i], ele)
        else:
            print '<td>%s</td><td><input type="text" name="%s" size="40" value="%s" required/></td>' %(attrAddress[i],attrAddress[i],ele)
        i+=1;
        print "</tr>"
        
print "</tbody></table>"
        
    
print "</fieldset>"
print '<br><input type="submit" value = "Update"/>'


if((user_cfv == False) and (user_pv == False)):
    print """<button formaction="MakeCFV.py?id=%s" >Make Crowd Funding Viewer</button>""" % userID;
    print """<button formaction="MakePV.py?id=%s" >Make Premium Viewer</button>""" % userID;
elif((user_cfv == True) and (user_pv == True)):
    print '';
elif(user_pv == True):
    print """<button formaction="MakeCFV.py?id=%s" >Make Crowd Funding Viewer</button>""" % userID;    
elif(user_cfv == True):
    print """<button formaction="MakePV.py?id=%s" >Make Premium Viewer</button>""" % userID;



print '</form>'
print '</div>'

#--------------------------------------------------------


# footer + end of document
print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.commit()
cursor.close()
db.close()
sess.close()


