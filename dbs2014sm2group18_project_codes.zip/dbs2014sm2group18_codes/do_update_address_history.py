# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect, util, time

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# get the loggedIn info
loggedIn = sess.data.get('loggedIn')

print "%s\nContent-Type: text/html\n" % (sess.cookie)

# redirect to login.py.
if not(loggedIn):
    # redirect to home page
    print """\
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="refresh" content="0;url=%s">
    </head>
    <body>
    </body>
    """ % redirect.getRelativeURL("Login.py")

else:
    # Get a DB connection
    try:
        db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
        cursor = db.cursor()
    except:
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("dberror.py")
        sess.close()
        quit()
        
        
    userName = sess.data.get('userName');
    # Check if this user is admin or not
    sql = """
        SELECT UserType
        FROM User
        WHERE UserName = '%s'
        """ % userName
    cursor.execute(sql)
    row = cursor.fetchone()
    
    #if not admin, go to error msg page(make it later)
    if row[0] != 'A':
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("AccessDenied.py")
        sess.close()
        cursor.close()
        quit()

#----------permission checked-----------------#


msg = "Successfully Updated"
page = "MaintainViewers.py"


def redirect_to_the_page(str):
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
            """ % redirect.getRelativeURL(str)
    
attrAddress = ['StreetAddressLine1', 'StreetAddressLine2', 'MinorMuniciplity',
               'MajorMuniciplity', 'GoverningDistrict', 'PostCode', 'Country'] 

form = cgi.FieldStorage()
userID = form['userID'].value
AddressNum = form['addressNum'].value


sqlCurAdd = """SELECT StreetAddressLine1, StreetAddressLine2, MinorMuniciplity,
                      MajorMuniciplity, GoverningDistrict, PostCode, Country, Address.AddressID, StartDate FROM Viewer
                      INNER JOIN ViewerAddress
                      ON Viewer.ViewerID = ViewerAddress.ViewerID
                      INNER JOIN Address
                      ON ViewerAddress.AddressID = Address.AddressID 
                      WHERE ViewerAddress.EndDate IS NOT NULL
                      AND Viewer.ViewerID = %s
                      ORDER BY StartDate; """ %(userID)  

cursor.execute(sqlCurAdd)
result = cursor.fetchall()
theAddress = result[int(AddressNum)]
    
isChanged = False
i = 0
for ele in attrAddress:
    if(form.has_key(attrAddress[i])):
        if (theAddress[i] != form[attrAddress[i]].value):
            isChanged = True
    else:
        if (theAddress[i] != None):
            isChanged = True   
    i+=1                
           
    
if(isChanged):    
    #check the updated address already exists
    addrCheck = "SELECT AddressID FROM Address WHERE "
    i = 0;
    for ele in attrAddress:
        if(form.has_key(attrAddress[i])):
            if(i == 6):
                addrCheck+="%s = '%s';" %(attrAddress[i], form[attrAddress[i]].value)
            else:
                addrCheck+="%s = '%s' AND " %(attrAddress[i], form[attrAddress[i]].value)
        else:
            addrCheck+="%s IS NULL AND " % attrAddress[i]
        i+=1
    cursor.execute(addrCheck)
    result = cursor.fetchone()
    
    
    #if the updated address already exists in database
    if(result):
        sqlAddress = """UPDATE ViewerAddress 
                         SET AddressID = %s
                         WHERE ViewerID = %s AND AddressID = %s AND StartDate = '%s';""" %(result[0], useID, theAddress[7], theAddress[8])
        

    #now then make a new address entity and update the ViewerAddress entity
    else:
        sqlAddress = "INSERT INTO Address Values (DEFAULT, "
        i = 0
        for ele in attrAddress:
            if(form.has_key(attrAddress[i])):
                if(i == 6):
                    sqlAddress+=" '%s'); " %form[attrAddress[i]].value
                else:
                    sqlAddress+=" '%s', " %form[attrAddress[i]].value
            else:
                sqlAddress+="NULL, "
            i+=1
            
        sqlAddress+= "SET @EID = LAST_INSERT_ID();"
        sqlAddress+= """UPDATE ViewerAddress 
                         SET AddressID = @EID
                         WHERE ViewerID = %s AND AddressID = %s AND StartDate = '%s';""" %(userID, theAddress[7], theAddress[8])


try:
    cursor.execute(sqlAddress)
    cursor.close()
    db.commit()
    
except:
    cursor.close()
    db.rollback()


db.close()
sess.close()   

redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %(msg, page))








