# dberror.py
# Description: Redirect here when databse exception raised
# Author: Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# header area
print """\
    <!-- Header with company logo -->
    <div style="margin:auto;padding:100px 0;text-align:center;" id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    </a>
    <h1>Connection Error</h1>
    <p>We are having some database issues, please try again later.</p>
    </div>"""
