# Description: Edit Game Profile
# Author: Heng Lin, modified from codes created by Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect, xstr

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % xstr.xstr(sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
    # not logged in: redirect to Login
    print redirect.getRedirectHead(redirect.getRelativeURL("Login.py"))
    db.close()
    sess.close()
    quit()    

# logged in: validate user
try:
    cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""", sess.data.get('userName'))          
except:
    # database error
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        # invalid user: redirect to do_logout
        print redirect.getRedirectHead(redirect.getRelativeURL("do_logout.py"))
        db.close()
        sess.close()
        quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A', 'P')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
    # access denied
    print redirect.getRedirectHead(redirect.getRelativeURL("AccessDenied.py"))
    db.close()
    sess.close()
    quit()

#=====================================================================================
# Parameter Validation
#=====================================================================================
# if no id passed, redirect to MaintainGames.py
if (not form.has_key('id')):
    print redirect.getRedirectHead(redirect.getRelativeURL("MaintainGames.py"))
    sess.close()
    quit()
else:
    ID = form.getfirst('id')

#=====================================================================================
# Page Head
#=====================================================================================
# head of HTML document
print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

#=====================================================================================
# Page Body
#=====================================================================================
# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % xstr.xstr(sess.data.get('userName')
else:
    print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a class="active" href="MaintainGames.py">Games</a></li>
    <li><a href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a href="MaintainPlayer.py">Players</a></li>
    <li><a href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

print """<h1>Edit Game Profile</h1>"""

try:             
    cursor.execute("""SELECT * FROM Game WHERE GameID = %s;""", ID)
except:
    print """\
        <p>We could not process your query.<p>"""
        
else:
    if (cursor.rowcount == 1):
        # record found, print form
        GameDetails = cursor.fetchone()
        print """\
            <form action="do_EditGameProfile.py" name="form" method="post">
            <fieldset>
            <legend>Game details</legend>
            <table class="form">
            <tbody>"""
        
        # input for game title
        print"""\
            <tr>
                <td><label for="GameID">Game ID</label></td>
                <td><input type="text" name="GameID"value="%s" readonly></input></td>
            </tr>""" % xstr.xstr(GameDetails[0]                
        
        # input for game title
        print"""\
            <tr>
                <td><label for="GameTitle">Game Title</label></td>
                <td><input type="text" name="GameTitle"value="%s"></input></td>
            </tr>""" % xstr.xstr(GameDetails[1])

        # input for genre
        print """\
            <tr>
                <td><label for="Genre">Genre</label></td>
                <td><input type="text" name="Genre" value="%s" ></input></td>
            </tr>""" % xstr.xstr(GameDetails[2])

        # input for Platform
        print """\
            <tr>
                <td><label for="Platform">Platform</label></td>
                <td><input type="text" name="Platform" value="%s" required></input></td>
            </tr>""" % xstr.xstr(GameDetails[6])

        # input for star rating
        print """\
            <tr>
                <td><label for="StarRating">Star Rating</label></td>
                <td><input type="number" min="1" max="5" name="StarRating" value="%s"></input></td>
            </tr>""" % xstr.xstr(GameDetails[4])
        
        # dropdown for Classification Rating
        temp0 = ""; temp1 = ""; temp2 = ""; temp3 = ""; temp4 = ""; temp5 = "";    
        select = "selected"
    
        if (GameDetails[5] == "G"):
            temp0 = select;
        elif (GameDetails[5] == "PG"):
            temp1 = select;
        elif (GameDetails[5] == "M"):
            temp2 = select;
        elif (GameDetails[5] == "MA15+"):
            temp3 = select;
        elif (GameDetails[5] == "R18+"):
            temp4 = select;
        elif (GameDetails[5] == "RC"):
            temp5 = select;
        
        print """\
            <tr>
                <td><label for="ClassificationRating">Classification Rating</label></td>
                <td>
                    <select name="ClassificationRating" required>
                        <option value="G" %s >G</option>
                        <option value="PG" %s >PG</option>
                        <option value="M" %s >M</option>
                        <option value="MA15+" %s >MA 15+</option>
                        <option value="R18+" %s >R 18+</option>
                        <option value="RC" %s >RC</option>
                    </select>
                </td>
            </tr>""" % xstr.xstr(temp0, temp1, temp2, temp3, temp4, temp5)
        
        # Promotion Link
        print """\
            <tr>
                <td><label for="PromotionLink">Promotion Link</label></td>
                <td><input type="text" name="PromotionLink" value="%s" ></input></td>
            </tr>""" % xstr.xstr(GameDetails[7])
        
        # Cost
        print """\
            <tr>
                <td><label for="Cost">Cost</label></td>
                <td><input type="text" name="Cost" value="%s" ></input></td>
            </tr>""" % xstr.xstr(GameDetails[8])
        
        # Review
        print """\
            <tr>
                <td><label for="Review">Review</label></td>
                <td><Textarea name="Review" style="resize:none" cols=50 rows=5 placeholder="250 characters max" >%s</Textarea></td>
            </tr>""" % xstr.xstr(GameDetails[3])
        
        print """\
            </tbody>
            </table>
            </fieldset>
            <tr><td><input type="submit" value="Submit"></input></td></tr>
            </form>"""
    else:
        print """<p>No record exists.</p>"""



#=====================================================================================
# Footer
#=====================================================================================

print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()
