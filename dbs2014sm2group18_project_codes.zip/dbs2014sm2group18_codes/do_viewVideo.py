# Script to view video
# Aaron Priestley
# 19 10 2014

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()

#===========================================
# LOGIN VALIDATION
#===========================================
    
validUser = False
rdPage = None
message = ""
isCFV = False
isPV = False
if sess.data.get('loggedIn'):
    #check that the user is a viewer
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName = %s
            """, (MySQLdb.escape_string(sess.data.get('userName'))))
    if cursor.rowcount == 1:
        # user is valid viewer, but make checks about subtypes (for later)
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        if (UType == 'V'):
            cursor.execute ("""
                    SELECT *
                    FROM CrowdFundingViewer
                    WHERE ViewerID = %s
                """, (UID))
            rows = []
            CFVrows = cursor.fetchall()
            isCFV = (len(CFVrows) > 0)
            rows += CFVrows
            cursor.execute ("""
                    SELECT *
                    FROM PremiumViewer
                    WHERE ViewerID = %s
                """, (UID))
            PVrows = cursor.fetchall()
            isPV = (len(PVrows) > 0)
            rows += PVrows
            validUser = True
        else:
            # login detected but not for a viewer, query again to find rdPage
            message = "Redirecting.."
            if UType == 'P':
                # go to a player page
                rdPage = "CreateVideo.py"
            elif UType == 'A':
                # go to an admin page
                rdPage = "MaintainVideos.py"
            else:
                # user of no type found (likely hack), go to logout page
                rdPage = "do_logout.py"
                message = "Logging out.."
    else:
         # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    # no login detected
    validUser = True
    
#===========================================
# PAGE DISPLAY AND MAIN CONTENT
#===========================================
        
if (not validUser):
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
else:    
    form = cgi.FieldStorage()
    #-----------------------------------------------------------------------------------------
    #get previous order data for user if CFV or PV
    CFVOrders = []
    PVOrders = []
    if isCFV or isPV:
        cursor.execute("""SELECT Video.VideoID,
    ViewerOrderLine.ViewedStatus,
    ViewerOrderLine.FlagPerk
    FROM Video NATURAL JOIN ViewerOrderLine
    NATURAL JOIN ViewerOrder
    WHERE
    ViewerOrder.ViewerID = %s
    """, UID)
        if cursor.rowcount > 0:
            rows = cursor.fetchall()
        else:
            rows = []
        for item in rows:
            if item[2] == True:
                CFVOrders.append(item[0])
            else:
                PVOrders.append(item[0])
    viewVid = form.getvalue('viewVid')
    if ((int(viewVid) in CFVOrders) or (int(viewVid) in PVOrders)):
        try:
            cursor.execute(""" 
            UPDATE ViewerOrderLine SET ViewerOrderLine.ViewedStatus = 'V'
            WHERE ViewerOrderLine.VideoID = %s AND ViewerOrderLine.ViewerOrderID 
                           IN (SELECT ViewerOrderID 
                           FROM ViewerOrder WHERE ViewerID = %s)""",
                           (viewVid, UID))
            db.commit()
        except:
            redir = "BrowseVideos.py"
            message = "Technical problem. Please try again later."
            viewVid = None
            db.rollback()
    # check if video is premium content
    if viewVid != None:
        cursor.execute("SELECT VideoType FROM Video WHERE VideoID = %s" % (viewVid))
        vidType = cursor.fetchone()[0]  
        cursor.execute("""
    SELECT DISTINCT Video.VideoType,
    InstanceRun.InstanceRunName AS InstanceName, 
    InstanceRun.CategoryName AS Category,
    Video.VideoType As VideoType,
    Game.GameTitle As Game,
    Game.Genre As Genre, 
    Game.PromotionLink As GameURL,
    Game.StarRating As GameRating,
    Video.VideoID As ID,
    Video.Price As Price,
    ViewerOrderLine.ViewedStatus As Viewed,
    ViewerOrderLine.FlagPerk As Perk,
    Video.URL As VideoURL
    FROM Video LEFT JOIN InstanceRun ON Video.InstanceRunID = InstanceRun.InstanceRunID
    LEFT JOIN ViewerOrderLine ON Video.VideoID = ViewerOrderLine.VideoID
    INNER JOIN Game ON InstanceRun.GameID = Game.GameID WHERE Video.VideoID = %s GROUP BY Video.VideoID;
    """ %  (viewVid))
        redir = cursor.fetchone()[12]
        message = "Loading.."
    else:
        vidType = None
        redir = "BrowseVideos.py"
        message = "Redirecting.."
    if (vidType == 'Premium' and (int(viewVid) not in PVOrders and int(viewVid) not in CFVOrders)):
        redir = "BrowseVideos.py"
        message = "Restricted Content. Please purchase before viewing."
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redir,message)
    #-----------------------------------------------------------------------------------------
# clean up
db.close()
sess.close()