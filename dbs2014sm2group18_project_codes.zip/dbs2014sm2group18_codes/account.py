# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()

validUser = False
rdPage = None
message = ""
if sess.data.get('loggedIn'):
    #check that the user is a viewer. if not a viewer, redirect
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName = %s
            """, (MySQLdb.escape_string(sess.data.get('userName'))))
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        # login detected, query again to find rdPage
        message = "Redirecting.."
        if UType == 'V':
            rdPage = "MyViewerAccount.py"
        elif UType == 'P':
            # go to a player page
            rdPage = "MyPlayerAccount.py"
        elif UType == 'A':
            # go to an admin page
            rdPage = "MaintainVideos.py"
        else:
            # user of no type found (likely hack), go to logout page
            rdPage = "do_logout.py"
            message = "Logging out.."
    else:
        # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    # user of no type found (likely hack), go to logout page
    rdPage = "Login.py"
    message = "Redirecting.."
print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
cursor.close()
db.close()