# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# get the loggedIn info
loggedIn = sess.data.get('loggedIn')

print "%s\nContent-Type: text/html\n" % (sess.cookie)

# redirect to login.py.
if not(loggedIn):
    # redirect to home page
    print """\
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="refresh" content="0;url=%s">
    </head>
    <body>
    </body>
    """ % redirect.getRelativeURL("Login.py")

else:
    # Get a DB connection
    try:
        db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
        cursor = db.cursor()
    except:
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("dberror.py")
        sess.close()
        quit()
        
        
    userName = sess.data.get('userName');
    # Check if this user is admin or not
    sql = """
        SELECT UserType
        FROM User
        WHERE UserName = '%s'
        """ % userName
    cursor.execute(sql)
    row = cursor.fetchone()
    
    #if not admin, go to error msg page(make it later)
    if row[0] != 'A':
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("AccessDenied.py")
        sess.close()
        cursor.close()
        quit()

#----------permission checked-----------------#

msg = "Successfully Deleted"
page = "MaintainViewers.py"


def redirect_to_the_page(str):
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
            """ % redirect.getRelativeURL(str)
        

#Delete data from backwards
form = cgi.FieldStorage()
userID = form['userID'].value

sql = """DELETE FROM ViewerAddress
            WHERE ViewerID = %s;""" %userID



sqlOrderID = """SELECT ViewerOrderID FROM ViewerOrder
                    WHERE ViewerID = %s;""" %userID
cursor.execute(sqlOrderID)
result = cursor.fetchall()
if(result):
    orderID = []
    for ele in result:
        orderID.append(ele[0])

    for ele in orderID:    
        sql += """DELETE FROM ViewerOrderLine 
                    WHERE ViewerOrderID = %s;""" % int(ele)
        
        
sql += """DELETE FROM ViewerOrder
             WHERE ViewerID = %s;""" % userID




sql += """DELETE FROM CrowdFundingViewer
             WHERE ViewerID = %s;""" % userID



sql += """DELETE FROM PremiumViewer
             WHERE ViewerID = %s;""" % userID



sql += """DELETE FROM ViewerType
            WHERE ViewerID = %s;""" %userID


sql += """DELETE FROM Viewer
            WHERE ViewerID = %s;""" %userID


sql += """DELETE FROM User
            WHERE UserID = %s;""" %userID





try:
    cursor.execute(sql)
    cursor.close()
    db.commit()
except:
    cursor.close()
    db.rollback()


db.close()
sess.close()


redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %(msg, page))



