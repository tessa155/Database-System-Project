# Equipment.py
# coding: latin-1
# Author: Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (sess.data.get('loggedIn')):
    # logged in: validate user
    try:
        cursor.execute("""SELECT UserID, UserType
                          FROM User
                          WHERE UserName = %s;""", sess.data.get('userName'))          
    except:
        # database error
        print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
        db.close()
        sess.close()
        quit()
    else:
        if (cursor.rowcount != 1):
            # invalid user: redirect to do_logout
            print redirect.getRedirectHead(redirect.getRelativeURL("do_logout.py"))
            db.close()
            sess.close()
            quit()
        else:
            # user is valid - check for viewer type
            sessionUserID = cursor.fetchone()[0]
            sessionDisplayName = sess.data.get('userName')
            cursor.execute("""SELECT ViewerType FROM ViewerType WHERE ViewerID = %s;""", sessionUserID)
            sessionViewerTypes = list(row[0] for row in cursor.fetchall()) # list of viewertypes for the current viewer (eg. ['C', 'P'])

            # get personalised name
            if ('C' in sessionViewerTypes):
                cursor.execute("""SELECT FirstName FROM CrowdFundingViewer WHERE ViewerID = %s;""", sessionUserID)
                sessionDisplayName = cursor.fetchone()[0]

#=====================================================================================
# Page Head
#=====================================================================================
# head of HTML document
print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

#=====================================================================================
# Page Body
#=====================================================================================
# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sessionDisplayName
else:
    print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="BrowseVideos.py">Videos</a></li>
    <li><a href="Players.py">Players</a></li>
    <li><a href="Games.py">Games</a></li>
    <li><a href="Venues.py">Venues</a></li>
    <li><a href="Equipment.py">Equipment</a></li>
    <li><a class="active" href="About.py">About</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

print """<h1>About WWAG</h1>"""
print """<br/>"""

print """
<p>
The ‘Wil Wheaton Appreciation Guild’ (WWAG) is a company that creates and uploads videos of entertaining gameplay to a 3rd party website for the public and premium viewers to enjoy. The company makes money through selling their premium content and the advertising revenue on video pageviews. WWAG has no official association with the celebrity Wil Wheaton and has received many cease and desist letters concerning the use of Wil Wheaton’s likeness and appearance.
The company was founded in 2001 as a primarily Australian organisation, but has since grown to have players from many countries. The players typically meet on Friday nights and conduct what they call ‘instance runs’. Instance runs are essentially stand-alone game playing sessions. Despite ‘instance runs’ typically be associated with World of Warcraft, the company uses the term to speak about any kind of game. A typical instance run could involve an attempt at completing game content in short period of time in a small team of players, a match of digital soccer or 20 minutes of Minecraft gameplay. Instance runs are recorded, edited and later uploaded as videos.
The company’s first instance run was in 2002. Their 7th and 8th instance runs were world-first achievements, meaning no other group of players completed that particular game content before them. Their success allowed them attract more highly skilled players, more viewers for their videos and accomplish even more prestigious in-game achievements.
Over the last 13 years WWAG has become one of the most successful groups of players in the Asia-Pacific region, growing to 10 times its original size. Currently the players win regular in-game achievements, such as world-firsts, and have gained a large following of fans.
</p>
"""

#=====================================================================================
# Footer
#=====================================================================================

print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()
