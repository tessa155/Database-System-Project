# Equipment.py
# coding: latin-1
# Author: Malcolm Karutz, Aaron Priestley

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if not (sess.data.get('loggedIn')):
    print redirect.getRedirectHead(redirect.getRelativeURL("BrowseVideos.py"))
    sess.close()
    quit()
else:
    # logged in: validate user
    try:
        cursor.execute("""SELECT UserID, UserType
                          FROM User
                          WHERE UserName = %s;""", sess.data.get('userName'))          
    except:
        # database error
        print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
        db.close()
        sess.close()
        quit()
    else:
        if (cursor.rowcount != 1):
            # invalid user: redirect to do_logout
            print redirect.getRedirectHead(redirect.getRelativeURL("do_logout.py"))
            db.close()
            sess.close()
            quit()
        else:
            # user is valid - check for viewer type
            sessionUserID = cursor.fetchone()[0]
            sessionDisplayName = sess.data.get('userName')
            cursor.execute("""SELECT ViewerType FROM ViewerType WHERE ViewerID = %s;""", sessionUserID)
            sessionViewerTypes = list(row[0] for row in cursor.fetchall()) # list of viewertypes for the current viewer (eg. ['C', 'P'])

            # get personalised name
            if ('C' in sessionViewerTypes):
                cursor.execute("""SELECT FirstName FROM CrowdFundingViewer WHERE ViewerID = %s;""", sessionUserID)
                sessionDisplayName = cursor.fetchone()[0]

#=====================================================================================
# Page Head
#=====================================================================================
# head of HTML document
print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

#=====================================================================================
# Page Body
#=====================================================================================
# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sessionDisplayName
else:
    print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="BrowseVideos.py">Videos</a></li>
    <li><a href="Players.py">Players</a></li>
    <li><a href="Games.py">Games</a></li>
    <li><a href="Venues.py">Venues</a></li>
    <li><a href="Equipment.py">Equipment</a></li>
    <li><a href="About.py">About</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

print """<h1>My account</h1>"""

print """<h2>Account details</h2>"""
sql = """
SELECT
    UserName,
    DateOfBirth,
    Email
FROM User INNER JOIN Viewer ON UserID = ViewerID
WHERE UserID = %s AND ViewerID = %s;
"""
cursor.execute(sql, (sessionUserID, sessionUserID))

print """
<table class="details">
<tr><td><b>Username:</b></td><td>%s</td></tr>
<tr><td><b>DOB:</b></td><td>%s</td></tr>
<tr><td><b>Email:</b></td><td>%s</td></tr>
</table>
""" % cursor.fetchone()

if ('P' in sessionViewerTypes):
    print """<h2>My subscription</h2>"""

    sql = """
    SELECT RenewalDate FROM PremiumViewer WHERE ViewerID = %s AND RenewalDate > DATE(NOW());
    """
    cursor.execute(sql, sessionUserID)

    if (cursor.rowcount > 0):
        print """You are subscribed until %s.""" % cursor.fetchone()[0]
    else:
        print """You are not currently subscribed."""


    # current address details
    print """<h2>Current address</h2>"""

    sql = """
    SELECT
        StreetAddressLine1,
        StreetAddressLine2,
        MinorMuniciplity,
        MajorMuniciplity,
        GoverningDistrict,
        PostCode,
        Country
    FROM Address
    WHERE Address.AddressID IN 
        (SELECT AddressID
            FROM ViewerAddress
            WHERE ViewerID = %s AND EndDate IS NULL);
    """
    cursor.execute(sql, sessionUserID)
    if (cursor.rowcount == 1):
        for detail in cursor.fetchone():
            if (detail != None):
                print detail
    else:
        print """Your account has no current address."""


# donation information
if ('C' in sessionViewerTypes):
    print """<h2>My donations</h2>"""
    sql = """
    SELECT FirstName, LastName, TotalAmountDonated, PerkCreditbalance
    FROM CrowdFundingViewer WHERE ViewerID = %s;
    """
    cursor.execute(sql, sessionUserID)
    print """
    <table class="details">
    <tr><td><b>First name:</b></td><td>%s</td></tr>
    <tr><td><b>Last name:</b></td><td>%s</td></tr>
    <tr><td><b>Total donated:</b></td><td>$%s</td></tr>
    <tr><td><b>Perk credit balance:</b></td><td>%s</td></tr>
    </table>
    """ % cursor.fetchone()
    
if ('P' in sessionViewerTypes):
    print """ <a href = "ViewAddressHistory.py">Address History</a></br>"""
print """ <a href = "EditViewerAccount.py">Update Details</a>"""



#=====================================================================================
# Footer
#=====================================================================================

print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()
