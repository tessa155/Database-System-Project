# Video.py
# description: Public pages for viewing video details
# Author: Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (sess.data.get('loggedIn')):
    # logged in: validate user
    try:
        cursor.execute("""SELECT UserID, UserType
                          FROM User
                          WHERE UserName = %s;""", sess.data.get('userName'))          
    except:
        # database error
        print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
        db.close()
        sess.close()
        quit()
    else:
        if (cursor.rowcount != 1):
            # invalid user: redirect to do_logout
            print redirect.getRedirectHead(redirect.getRelativeURL("do_logout.py"))
            db.close()
            sess.close()
            quit()
        else:
            # user is valid - check for viewer type
            sessionUserID = cursor.fetchone()[0]
            sessionDisplayName = sess.data.get('userName')
            cursor.execute("""SELECT ViewerType FROM ViewerType WHERE ViewerID = %s;""", sessionUserID)
            sessionViewerTypes = list(row[0] for row in cursor.fetchall()) # list of viewertypes for the current viewer (eg. ['C', 'P'])

            # check that viewer is currently subscribed
            if ('P' in sessionViewerTypes):
                cursor.execute("""SELECT RenewalDate FROM PremiumViewer WHERE ViewerID = %s AND RenewalDate > CURDATE();""", sessionUserID)
                if (cursor.rowcount > 0):
                    sessionSubcribedStatus = True
                else:
                    sessionSubcribedStatus = False

            # get personalised name
            if ('C' in sessionViewerTypes):
                cursor.execute("""SELECT FirstName FROM CrowdFundingViewer WHERE ViewerID = %s;""", sessionUserID)
                sessionDisplayName = cursor.fetchone()[0]

#=====================================================================================
# Id Parameter Verification
#=====================================================================================
sql = """\
SELECT
    VideoID,
    URL,
    Price,
    VideoType,
    InstanceRunID
FROM Video
WHERE VideoID = %s;"""

try:
    cursor.execute(sql, form.getfirst('id'))
except:
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        print redirect.getRedirectHead(redirect.getRelativeURL("BrowseVideos.py"))
        db.close()
        sess.close()
        quit()
    else:
        videoDetails = cursor.fetchone()

#=====================================================================================
# Page Head
#=====================================================================================
# head of HTML document
print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <script src="sorttable.js" type="text/javascript"></script>
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

#=====================================================================================
# Page Body
#=====================================================================================
# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sessionDisplayName
else:
    print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a class="active" href="BrowseVideos.py">Videos</a></li>
    <li><a href="Players.py">Players</a></li>
    <li><a href="Games.py">Games</a></li>
    <li><a href="Venues.py">Venues</a></li>
    <li><a href="Equipment.py">Equipment</a></li>
    <li><a href="About.py">About</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

# InstanceRun details
print """<h1>Video</h1>"""

print """\
            <table class="details">
            <tbody>
                    <tr><td><b>Video Type</b></td><td>%s</td></tr>
                    <tr><td><b>Price</b></td><td>%s</td></tr>
            </tbody>
            </table><br>""" % (videoDetails[3], videoDetails[2])

# if video is free show "watch now" button
if (videoDetails[2] is None or videoDetails == 0):
    print """<a href="do_viewVideo.py?viewVid=%s">Watch now!</a>""" % videoDetails[0]

else:
    if (sess.data.get('loggedIn')):
        sql = """SELECT VideoID FROM ViewerOrder NATURAL JOIN ViewerOrderLine WHERE ViewerID = %s AND FlagPerk != 0;"""
        cursor.execute(sql, sessionUserID)
        ownedVideos = list(row[0] for row in cursor.fetchall())

        sql = """SELECT VideoID FROM ViewerOrder NATURAL JOIN ViewerOrderLine WHERE ViewerID = %s AND FlagPerk = 0;"""
        cursor.execute(sql, sessionUserID)
        premiumOrderedVideos = list(row[0] for row in cursor.fetchall())
        
        try:
            cartItems = sess.data['cart'].split
        except:
            cartItems = []
            
        # if video is in cart show "in cart" button
        if (str(videoDetails[0]) in cartItems):
            print """<a href="MyCart.py">In cart</a>"""

        # elif video is owned show "watch now" button
        elif (videoDetails[0] in ownedVideos):
            print """<a href="do_viewVideo.py?viewVid=%s">Watch now!</a>""" % videoDetails[0]

        # elif user is subscribed and they have orded the video, show "watch now" button
        elif ('P' in sessionViewerTypes and sessionSubcribedStatus == True and videoDetails[0] in premiumOrderedVideos):
            print """<a href="do_viewVideo.py?viewVid=%s">Watch now!</a>""" % videoDetails[0]

        # else show "add to cart" - video is premium and not already ordered
        else:
            print """<form action = "do_addToCart.py">
                     <input name="%s" type="checkbox" value="off"></input>
                     <input name="addToCart" type="submit" value="Add to cart"></input>
                     </form>""" % videoDetails[0]

    else:
        print """<form action = "do_addToCart.py">
                 <input name="%s" type="checkbox" value="off"></input>
                 <input name="addToCart" type="submit" value="Add to cart"></input>
                 </form>""" % videoDetails[0]


instanceRunID = videoDetails[4]

sql = """\
SELECT
    InstanceRunID,
    concat(Supervisor.FirstName, ' \"', Supervisor.GameHandle, '\" ', Supervisor.LastName),
    InstanceRunName,
    RecordedTime,
    CategoryName,
    Game.GameTitle,
    Venue.VenueName,
    InstanceRun.SupervisorID,
    Game.GameID,
    Venue.VenueID
FROM InstanceRun
    INNER JOIN Player as Supervisor ON InstanceRun.SupervisorID = Supervisor.PlayerID
    INNER JOIN Game ON InstanceRun.GameID = Game.GameID
    INNER JOIN Venue ON InstanceRun.VenueID = Venue.VenueID
WHERE InstanceRunID = %s;
"""

try:             
    cursor.execute(sql, instanceRunID)
except:
    print """\
        <p>We could not process your query.<p>"""
        
else:
    if (cursor.rowcount == 1):
        instanceRunDetails = cursor.fetchone()
        print """<hr>"""
        print """<h2>Instance Run Details</h2>"""
        print """\
            <table class="details">
            <tbody>
                    <tr><td><b>Supervisor</b></td><td><a href="Players.py#%s">%s</a></td></tr>
                    <tr><td><b>Name</b></td><td>%s</td></tr>
                    <tr><td><b>Recorded Time</b></td><td>%s</td></tr>
                    <tr><td><b>Category</b></td><td>%s</td></tr>
                    <tr><td><b>Game</b></td><td><a href="Games.py#%s">%s</a></td></tr>
                    <tr><td><b>Venue</b></td><td><a href="Venues.py#%s">%s</a></td></tr>
            </tbody>
            </table>""" % (instanceRunDetails[7],instanceRunDetails[1],instanceRunDetails[2],instanceRunDetails[3],instanceRunDetails[4],instanceRunDetails[8],instanceRunDetails[5],instanceRunDetails[9],instanceRunDetails[6])
            
        
    else:
        print """<p>No record exists.</p>"""

        
# Achievements
print """<hr/>"""
print """<h2>Achievements</h2>"""

sql = """\
SELECT
    AchievementName,
    WhenAchieved,
    RewardBody
FROM Achievement
WHERE InstanceRunID = %s;"""

try:             
    cursor.execute(sql, instanceRunID)

except:
    print """\
        <p>There was an error finding InstanceRunPlayers.<p>"""

else:
    if (cursor.rowcount != 0):
        print """\
            <table>
            <thead>
                <tr>
                    <th>Achievement name</th>
                    <th>When achieved</th>
                    <th>Rewarding body</th>
                </tr>
            </thead>
            <tbody>"""

        for row in cursor.fetchall():
            print "<tr>"
            for cell in row:
                print "<td>%s</td>" % cell
            print "</tr>"

        print """\
            </tbody>
            </table>"""

    else:
        print """\
            <p>There are no achievements recorded for this instance run.<p>"""


# InstanceRunPlayers
print """<hr/>"""
print """<h2>Instance Run Players</h2>"""

sql = """\
SELECT Player.PlayerID,
    concat(Player.FirstName, ' \"', Player.GameHandle, '\" ', Player.LastName),
    InstanceRunPlayer.EquipmentID,
    concat(Equipment.Make, ' ', Equipment.Model)
FROM InstanceRunPlayer
    INNER JOIN Player ON InstanceRunPlayer.PlayerID = Player.PlayerID
    LEFT OUTER JOIN Equipment ON InstanceRunPlayer.EquipmentID = Equipment.EquipmentID
WHERE InstanceRunPlayer.InstanceRunID = %s;"""

try:             
    cursor.execute(sql, instanceRunID)

except:
    print """\
        <p>There was an error finding InstanceRunPlayers.<p>"""

else:
    if (cursor.rowcount != 0):
        print """\
            <table class="list">
            <thead>
                <th>Player</th>
                <th>Equipment</th>
            </thead>
            <tbody>"""

        for row in cursor.fetchall():
            print "<tr>"
            print """<td><a href="Players.py#%s">%s</a></td>""" % (row[0], row[1])
            print """<td><a href="Equipment.py#%s">%s</a></td>""" % (row[2], row[3])
            print "</tr>"

        print """\
            </tbody>
            </table>"""

    else:
        print """\
            <p>This Instance Run has no Players.<p>"""



#=====================================================================================
# Footer
#=====================================================================================

print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()