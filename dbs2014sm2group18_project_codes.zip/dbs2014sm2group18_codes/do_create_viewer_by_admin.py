# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect, util, time

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# get the loggedIn info
loggedIn = sess.data.get('loggedIn')

print "%s\nContent-Type: text/html\n" % (sess.cookie)

# redirect to login.py.
if not(loggedIn):
    # redirect to home page
    print """\
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="refresh" content="0;url=%s">
    </head>
    <body>
    </body>
    """ % redirect.getRelativeURL("Login.py")

else:
    # Get a DB connection
    try:
        db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
        cursor = db.cursor()
    except:
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("dberror.py")
        sess.close()
        quit()
        
        
    userName = sess.data.get('userName');
    # Check if this user is admin or not
    sql = """
        SELECT UserType
        FROM User
        WHERE UserName = '%s'
        """ % userName
    cursor.execute(sql)
    row = cursor.fetchone()
    
    #if not admin, go to error msg page(make it later)
    if row[0] != 'A':
        print """\
            <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
                """ % redirect.getRelativeURL("AccessDenied.py")
        sess.close()
        cursor.close()
        quit()

#----------permission checked-----------------#

msg = "Successfully Registered"
page = "MaintainViewers.py"

attrAddress = ['StreetAddressLine1', 'StreetAddressLine2', 'MinorMuniciplity',
               'MajorMuniciplity', 'GoverningDistrict', 'PostCode', 'Country'] 


def redirect_to_the_page(str):
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
            """ % redirect.getRelativeURL(str)

form = cgi.FieldStorage()

#create user entity
sql = "INSERT INTO User Values "
if(form.has_key('UserName') and form.has_key('UserPassword')): 
    
    dup_check_sql = """SELECT * FROM User
                         WHERE UserName = '%s';""" %form['UserName'].value
    cursor.execute(dup_check_sql)
    result = cursor.fetchall()
    
    if not(result):
        sql+="(DEFAULT, '%s', '%s', 'V'); " %(form['UserName'].value, form['UserPassword'].value)
        sql+="SET @EID = LAST_INSERT_ID(); "
        
    else:
        redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %("This username already exists", "Create_Viewer_By_Admin.py?"))
        quit()
else:
    redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %("Username and Password are compulsory", "Create_Viewer_By_Admin.py"))
    quit()

#create viewer entity
sql+="INSERT INTO Viewer Values "
if(form.has_key('DateOfBirth') and form.has_key('Email')):
    sql+="(@EID, '%s', '%s'); " %(form['DateOfBirth'].value, form['Email'].value)
else:
    redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %("DateOfBirth and Email are compulsory", "Create_Viewer_By_Admin.py"))
    quit()
    
    
#create vewerType entity
sql+="INSERT INTO ViewerType Values "
if(form['type'].value == "CrowdFunding"):
    sql+="(@EID, 'C'); "
elif (form['type'].value == "Premium"):
    sql+="(@EID, 'P'); "
else:
    sql+="(@EID, 'C'), "
    sql+="(@EID, 'P'); "
    
    
#create subtype entity of viewer
if(form['type'].value == "CrowdFunding"):
    sql+="INSERT INTO CrowdFundingViewer Values "
    if (form.has_key('FirstName') and form.has_key('LastName') and form.has_key('Donation')):
        try: 
            donation = float(form['Donation'].value)
        except:
            redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %("Donation should be number", "Create_Viewer_By_Admin.py"))
            quit()
        sql+="(@EID, '%s', '%s', %s, %s); " %(form['FirstName'].value, form['LastName'].value, donation, donation/2) 
    else:
        redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %("First&LastNames and Donation are compulsory", "Create_Viewer_By_Admin.py"))
        quit()

elif (form['type'].value == "Premium"):
    sql+="INSERT INTO PremiumViewer Values "
    if(form.has_key('subscription')):
        sql+="(@EID, '%s'); " % util.dateCalculator(form['subscription'].value)
    else: 
        redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %("Subscription are compulsory", "Create_Viewer_By_Admin.py"))
        quit()
        
else:
    sql+="INSERT INTO CrowdFundingViewer Values "
    if (form.has_key('FirstName') and form.has_key('LastName') and form.has_key('Donation')):
        sql+="(@EID,'%s', '%s', %s, %s); " %(form['FirstName'].value, form['LastName'].value, 0, form['Donation'].value) 
    else:
        redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %("First&LastNames and Donation are compulsory", "Create_Viewer_By_Admin.py"))
        quit()
        
    sql+="INSERT INTO PremiumViewer Values "
    if(form.has_key('subscription')):
        sql+="(@EID, '%s'); " %util.dateCalculator(form['subscription'].value)
    else: 
        redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %("Subscription are compulsory", "Create_Viewer_By_Admin.py"))
        quit()
        
        
if (form['type'].value == "Both" or form['type'].value == "Premium"):
    addrCheck = "SELECT AddressID FROM Address WHERE "
    i = 0;
    for ele in attrAddress:
        if(form.has_key(attrAddress[i])):
            if(i == 6):
                addrCheck+="%s = '%s';" %(attrAddress[i], form[attrAddress[i]].value)
            else:
                addrCheck+="%s = '%s' AND " %(attrAddress[i], form[attrAddress[i]].value)
        else:
            addrCheck+="%s IS NULL AND " % attrAddress[i]
        i+=1

    cursor.execute(addrCheck)
    result = cursor.fetchone()
    
    if(result):
        sqlAddress = "INSERT INTO ViewerAddress VALUES (@EID, %s, '%s', NULL);" %(result[0],(time.strftime("%Y-%m-%d")))
        # now then make a new address entity and a new ViewerAddress entity
    else:
        sqlAddress = "INSERT INTO Address Values (DEFAULT, "
        i = 0
        for ele in attrAddress:
            if(form.has_key(attrAddress[i])):
                if(i == 6):
                    sqlAddress+=" '%s'); " %form[attrAddress[i]].value
                else:
                    sqlAddress+=" '%s', " %form[attrAddress[i]].value
            else:
                sqlAddress+="NULL, "
            i+=1
            
        sqlAddress+= "SET @EIDA = LAST_INSERT_ID();"
        sqlAddress+= "INSERT INTO ViewerAddress VALUES (@EID, @EIDA, '%s', NULL);" %(time.strftime("%Y-%m-%d")) 

        
        
    sql+=sqlAddress

try:
    cursor.execute(sql)
    cursor.close()
    db.commit()
except:
    cursor.close()
    db.rollback()


db.close()
sess.close()
  

#redirect
redirect_to_the_page("admin_msg.py?msg=%s&page=%s" %(msg, page))






    


