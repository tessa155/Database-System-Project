# The libraries we'll need
import sys, session, cgi, MySQLdb

# Get a DB connection
db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
cursor = db.cursor()

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print """\
%s
Content-Type: text/html
""" % (sess.cookie)
    
# head of HTML document
print """\
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>WWAG</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

# top bar and accountpanel
print """\
        <!-- Top bar with account panel (my account | logout) -->
        <div id="TopBar">
            <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """\t\t\t\tWelcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
else:
    print """\t\t\t\t<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
            </div>
        </div>"""


# header area
print """\
        <!-- Header with company logo -->
        <div id="Header">
            <a href="home.py" id="Logo">
                <img src="images/Logo.svg" alt="Logo"/>
                <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
            </a>
        </div>"""

# main nav
print """\
        <!-- Main navigation bar -->
        <div id="TopNav">
            <ul>
                <li><a href="BrowseVideos.py">Videos</a></li>
                <li><a href="MaintainPlayer.py">Players</a></li>
                <li><a href="MaintainGames.py">Games</a></li>
                <li><a href="MaintainVenues.py">Venues</a></li>
                <li><a href="MaintainEquipment.py">Equipment</a></li>
                <li><a href="about.py">About</a></li>
            </ul>
        </div>"""

# page area
print """\
        <!-- The main body section of the page -->
        <div id="PageWrapper">"""


#-----------------------------------------------------------------------------------------

print """\

    <h1>Create Account</h1>
"""

print """
    <form method="post" action="do_createViewerAccount.py">
        <p class="meta"><input type="text" name="username" required /> Username</p>
        <p class="meta"><input type="password" name="password" required /> Password</p>
        <p class="meta"><input type="password" name="c_password" required /> Confirm Password</p>
        <p class="meta"><input type="email" name="email" required /> Email</p>
        <p class="meta"><input type="date" max=2014-09-30 name="dob" required/> Date of Birth</p>
        <p style="font-size:80%;"><b>Terms and Conditions:</b> Any information you enter into WWAG's database belongs to WWAG and under no circumstances will your account be deleted.</p>
        <input type="submit" id="search-submit" value="Accept terms and conditions and continue" />
    </form>
"""


#-----------------------------------------------------------------------------------------


# footer + end of document
print """\
        </div>
        <!-- Footer area with copyright and links -->
        <div id="Footer">
            <div id="FooterContent" class="container">
                <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
            </div>
        </div>        
    </body>
</html>"""


# clean up
db.close()
sess.close()