# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()

validUser = False
rdPage = None
message = ""
if sess.data.get('loggedIn'):
    #check that the user is a viewer. if not a viewer, redirect
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName = %s
            """, sess.data.get('userName'))
    isPV = False
    isCFV = False
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        if UType == 'V':
        # go to a viewer page
            cursor.execute ("""
                    SELECT *
                    FROM CrowdFundingViewer
                    WHERE ViewerID = %s
                """, UID)
            CFVrows = cursor.fetchall()
            isCFV = (len(CFVrows) > 0)
            cursor.execute ("""
                    SELECT *
                    FROM PremiumViewer
                    WHERE ViewerID = %s
                """, UID)
            PVrows = cursor.fetchall()
            isPV = (len(PVrows) > 0)
            validUser = True
        elif UType == 'P':
            # continue showing this page to the player
            validUser = True
        elif UType == 'A':
            # go to an admin page
            rdPage = "MaintainVideo.py"
            message = "Redirecting.."
        else:
            # user of no type found (likely hack), go to logout page
            rdPage = "do_logout.py"
            message = "Logging out.."
    else:
        # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    rdPage = "Login.py"
    message = "Redirecting.."
        
if not validUser:
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
else:    
    # head of HTML document
    print """\
        <!doctype html>
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>WWAG</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>"""
    # top bar and accountpanel
    print """\
        <!-- Top bar with account panel (my account | logout) -->
        <div id="TopBar">
        <div id="AccountPanel">"""
    if sess.data.get('loggedIn'):
        print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
    else:
        print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""
    print """\
        </div>
        </div>"""
    # header area
    print """\
        <!-- Header with company logo -->
        <div id="Header">
        <a href="home.py" id="Logo">
        <img src="images/Logo.svg" alt="Logo"/>
        <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
        </a>
        </div>"""
    # main nav
    print """\
        <!-- Main navigation bar -->
        <div id="TopNav">
        <ul>
        <li><a class="active" href="BrowseVideos.py">Videos</a></li>
        <li><a href="Players.py">Players</a></li>
        <li><a href="Games.py">Games</a></li>
        <li><a href="Venues.py">Venues</a></li>
        <li><a href="Equipment.py">Equipment</a></li>
        <li><a href="About.py">About</a></li>
        </ul>
        </div>"""
    # page area
    print """\
        <!-- The main body section of the page -->
        <div id="PageWrapper">"""
    #-----------------------------------------------------------------------------------------
    # TO DO..
    print """ <div id = "PageContent">"""
    # preload player information
    sql = """ SELECT DateOfBirth, Email
    FROM Viewer WHERE 
        ViewerID = %s"""
    cursor.execute(sql, UID)
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        DOB = row[0]
        email = row[1]
    if (isPV):
        sql = """ SELECT RenewalDate
    FROM PremiumViewer WHERE 
        ViewerID = %s"""
        cursor.execute(sql, UID)
        if cursor.rowcount == 1:
            row = cursor.fetchone()
            renewDate = row[0]
    if (isCFV):
        sql = """ SELECT FirstName, LastName, PerkCreditBalance, TotalAmountDonated
    FROM CrowdFundingViewer WHERE 
        ViewerID = %s"""
        cursor.execute(sql, UID)
        if cursor.rowcount == 1:
            row = cursor.fetchone()
            fname = row[0]
            lname = row[1]
            balance = row[2]
            totDonated = row[3]
    if (isPV):
        sql = """ SELECT Address.StreetAddressLine1, Address.StreetAddressLine2,
    Address.MinorMuniciplity,
    Address.MajorMuniciplity, Address.GoverningDistrict, Address.PostCode,
    Address.Country FROM Address NATURAL JOIN ViewerAddress
    WHERE ViewerID = %s
    ORDER BY ViewerAddress.EndDate"""
    elif (UType == 'P'):
        sql = """ SELECT Address.StreetAddressLine1, Address.StreetAddressLine2,
    Address.MinorMuniciplity,
    Address.MajorMuniciplity, Address.GoverningDistrict, Address.PostCode,
    Address.Country FROM Address NATURAL JOIN PlayerAddress
    WHERE PlayerID = %s
    ORDER BY PlayerAddress.EndDate"""
    else:
        sql = ""
    if (sql != ""):
        cursor.execute(sql, UID)
    if sql != "" and cursor.rowcount >= 1:
        rows = cursor.fetchall()
        # display player information
        print """ <h2>Address History (%s)</h2><br/>"""  % (UName)
        for i in range(len(rows)):
            v_addr_str1 = rows[i][0]
            v_addr_str2 = rows[i][1]
            v_addr_minMun = rows[i][2]
            v_addr_majMun = rows[i][3]
            v_addr_govD = rows[i][4]
            v_addr_postalA = rows[i][5]
            v_addr_country = rows[i][6]
            print """
            <span class = "plrdetailhd">Address 1:</span> %s, %s, %s, %s, %s, %s, %s</br>
            """ % (v_addr_str1, v_addr_str2, 
            v_addr_minMun, v_addr_majMun, v_addr_postalA, v_addr_govD,
            v_addr_country)
            print "<br/>"
    else:
        print "No Address information available<br/>"
    #display edit link
    print ("""<a href = "%s">Back To Account</a>""" % 
    (redirect.getRelativeURL("account.py")))
    print """</div>"""
    #-----------------------------------------------------------------------------------------
    # footer + end of document
    print """\
        </div>
        <!-- Footer area with copyright and links -->
        <div id="Footer">
        <div id="FooterContent" class="container">
        <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
        </div>
        </div>        
        </body>
        </html>"""
# clean up
try:
    db.close()
    sess.close()
except:
    print ''