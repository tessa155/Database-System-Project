import datetime

def today():
    return datetime.date.today()

def dateCalculator(weeks):
    
    today = datetime.date.today()
    days = datetime.timedelta(days=(int(weeks)*7))
    return today+days


def dateFormatCheck(str):
    flag = True
    num = 0
    arr = str.split('-')
    for ele in arr:
        try:
            int(ele)
            num+=1
        except:
            flag = False
            
    if(flag and num==3):
        return True;
    else:
        return False;
        
    

    