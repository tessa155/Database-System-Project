# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect, traceback

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
    # not logged in: redirect to Login
    print redirect.getRedirectHead(redirect.getRelativeURL("Login.py"))
    db.close()
    sess.close()
    quit()    

# logged in: validate user
try:
    cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""", sess.data.get('userName'))          
except:
    # database error
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        # invalid user: redirect to do_logout
        print redirect.getRedirectHead(redirect.getRelativeURL("do_logout.py"))
        db.close()
        sess.close()
        quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
    # access denied
    print redirect.getRedirectHead(redirect.getRelativeURL("AccessDenied.py"))
    db.close()
    sess.close()
    quit()

#=====================================================================================
# Page Head
#=====================================================================================
# head of HTML document
print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

#=====================================================================================
# Page Body
#=====================================================================================
# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
else:
    print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a href="MaintainGames.py">Games</a></li>
    <li><a href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a href="MaintainPlayer.py">Players</a></li>
    <li><a class="active" href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""


# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

print """<h1>Maintain Viewer Accounts</h1>"""

#serching and sorting
print """
      <!-- Place for page navigation links -->

      <h2>Serach Viewers</h2>
            
      <!-- Search form for filtering and sorting the video query -->
      <div id="SearchBar" class="PageBox">
          <form method = "get" action = "MaintainViewers.py">

              username: <input id="SearchField" type="text" name="userName" placeholder="Search" />
                    
                  <select name="viewerSort">
                      <option value = "None">Sorting option</option>
                      <option value="UserID">sort by userID</option>
                      <option value="UserName">sort by username</option>
                      <option value="Email">sort by Email Address</option>
                  </select>

              <input type="submit" value="Send"> 
            </form>        
        </div>"""

# show the list of viewers
print "<br><hr>"
print """<h2>List of Viewers</h2>"""


#check passed parameters and show the result
form = cgi.FieldStorage()

userName = None

viewerSort = None

if form.has_key('userName'):
    userName = form['userName'].value
if form.has_key('viewerSort'):
    viewerSort = form['viewerSort'].value

#basic query
sql = """
        SELECT UserID, UserName, Email FROM User
            INNER JOIN Viewer 
            ON User.UserID = Viewer.ViewerID
            WHERE User.UserType = 'V' """


if(userName):
    sql+="AND User.UserName = '%s' " %userName
    
if (viewerSort and viewerSort != 'None'):
    sql+="ORDER BY %s " % viewerSort


cursor.execute(sql)


# show all the viewers
list_viewer = cursor.fetchall()
print """<p style="text-align:right"><a href="Create_Viewer_By_Admin.py">Register new Viewer</a></p>"""
print "<table>"
print """<thead><tr>
           <th> UserID </th>
           <th> Username </th>
           <th> Email Address </th>
           <th></th>
           <th></th>
       </tr></thead>"""
print "<tbody>"
for row in list_viewer:
    # check if user is a paid user
    cursor.execute(""" SELECT DISTINCT ViewerID FROM 
                   CrowdFundingViewer WHERE ViewerID = %s""", (row[0]))
    if cursor.rowcount != 0:
        isCFV = True
    else:
        isCFV = False
    cursor.execute(""" SELECT DISTINCT ViewerID FROM 
                   PremiumViewer WHERE ViewerID = %s""", (row[0]))
    if cursor.rowcount != 0:
        isPV = True
    else:
        isPV = False
    print "<tr>"
    print "<td> %s </td>"% row[0]
    print "<td> %s </td>"% row[1]
    print "<td> %s </td>"% row[2]
    print "<td><a href = 'ReadUpdateViewerByAdmin.py?userID=%s'>Read&Update</a></td>" % row[0]
    if isCFV or isPV:
        print """ <td><a href = "MaintainOrders.py?viewerfilter=%s">View Orders</a></td>""" % row[0]
    print "</tr>"

print "</tbody></table>"


#=====================================================================================
# Footer
#=====================================================================================

print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()
