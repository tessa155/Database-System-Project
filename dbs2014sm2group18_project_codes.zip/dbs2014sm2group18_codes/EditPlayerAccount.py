# Script to edit player account (player-side)
# Aaron Priestley
# 19 10 2014

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()

#===========================================
# LOGIN VALIDATION
#===========================================
    
validUser = False
rdPage = None
message = ""
if sess.data.get('loggedIn'):
    #check that the user is a viewer. if not a viewer, redirect
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName = %s
            """, (MySQLdb.escape_string(sess.data.get('userName'))))
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        if UType == 'V':
        # go to a player page
            rdPage = "MyViewerAccount.py"
            message = "Redirecting.."
        elif UType == 'P':
            # continue showing this page to the player
            validUser = True
        elif UType == 'A':
            # go to an admin page
            rdPage = "MaintainVideo.py"
            message = "Redirecting.."
        else:
            # user of no type found (likely hack), go to logout page
            rdPage = "do_logout.py"
            message = "Logging out.."
    else:
        # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    rdPage = "Login.py"
    message = "Redirecting.."
    
#===========================================
# PAGE DISPLAY AND MAIN CONTENT
#===========================================
        
if not validUser:
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
else:    
    # head of HTML document
    print """\
        <!doctype html>
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>WWAG</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>"""
    # top bar and accountpanel
    print """\
        <!-- Top bar with account panel (my account | logout) -->
        <div id="TopBar">
        <div id="AccountPanel">"""
    if sess.data.get('loggedIn'):
        print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
    else:
        print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""
    print """\
        </div>
        </div>"""
    # header area
    print """\
        <!-- Header with company logo -->
        <div id="Header">
        <a href="home.py" id="Logo">
        <img src="images/Logo.svg" alt="Logo"/>
        <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
        </a>
        </div>"""
    # main nav
    print """\
        <!-- Main navigation bar -->
        <div id="TopNav">
        <ul>
        <li><a class="active" href="BrowseVideos.py">Videos</a></li>
        <li><a href="Players.py">Players</a></li>
        <li><a href="Games.py">Games</a></li>
        <li><a href="Venues.py">Venues</a></li>
        <li><a href="Equipment.py">Equipment</a></li>
        <li><a href="About.py">About</a></li>
        </ul>
        </div>"""
    # page area
    print """\
        <!-- The main body section of the page -->
        <div id="PageWrapper">"""
    #-----------------------------------------------------------------------------------------
    print """ <div id = "PageContent">"""
    # preload player information to prefill form
    sql = """ SELECT FirstName, LastName, Role, ProfileDescription,
    Email, GameHandle, Phone, VoIP
    FROM Player WHERE 
        PlayerID = %s"""
    cursor.execute(sql, UID)
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        fname = row[0]
        lname = row[1]
        role = row[2]
        pdesc = row[3]
        email = row[4]
        ghandle = row[5]
        phone = row[6]
    # get supervisor information if any
    sql = """ SELECT s.FirstName, s.LastName
    FROM Player p, Player s WHERE 
        s.PlayerID = p.SupervisorID AND
        p.PlayerID = %s"""
    cursor.execute(sql, UID)
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        sup_fname = row[0]
        sup_lname = row[1]
    else:
        sup_fname = ""
        sup_lname = ""
    sql = """ SELECT Address.StreetAddressLine1, Address.StreetAddressLine2,
    Address.MinorMuniciplity,
    Address.MajorMuniciplity, Address.GoverningDistrict, Address.PostCode,
    Address.Country FROM Address NATURAL JOIN PlayerAddress
    WHERE PlayerID = %s"""
    cursor.execute(sql, UID)
    p_addr_str1 = None
    p_addr_str2 = None
    p_addr_minMun = None
    p_addr_majMun = None
    p_addr_govD = None
    p_addr_postalA = None
    p_addr_country = None
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        p_addr_str1 = row[0]
        p_addr_str2 = row[1]
        p_addr_minMun = row[2]
        p_addr_majMun = row[3]
        p_addr_govD = row[4]
        p_addr_postalA = row[5]
        p_addr_country = row[6]
    # display player information form
    UName = "" if UName == None else UName
    fname = "" if fname == None else fname
    lname = "" if lname == None else lname
    sup_fname = "" if sup_fname == None else sup_fname
    sup_lname = "" if sup_lname == None else sup_lname
    role = "" if role == None else role
    pdesc = "" if pdesc == None else pdesc
    email = "" if email == None else email
    ghandle = "" if ghandle == None else ghandle
    phone = "" if phone == None else phone
    print """ <h2>Edit Player Details (%s)</h2><br/>
    <form id = "playerselfupdate" action = "do_editPlayerAccount.py" method = "post">
    Description: <br/><input type = "text" name = "pdesc" value = "%s" maxlength = "255"/><br/>
    Game Handle: <br/><input type = "text" name = "phandle" value = "%s" maxlength = "50"/><br/>
    <br/><br/>
    ADDRESS<br/>
    Street 1: <br/><input type = "text" name = "p_addr_str1" value = "%s" maxlength = "50"/><br/>
    Street 2: <br/><input type = "text" name = "p_addr_str2" value = "%s" maxlength = "50"/><br/>
    Minor Municipality: <br/><input type = "text" name = "p_addr_minMun" value = "%s" maxlength = "50"/><br/>
    Major Municipality: <br/><input type = "text" name = "p_addr_majMun" value = "%s" maxlength = "50"/><br/>
    District: <br/><input type = "text" name = "p_addr_govD" value = "%s" maxlength = "50"/><br/>
    Area Code: <br/><input type = "text" name = "p_addr_postalA" value = "%s" maxlength = "10"/><br/>
    Country: <br/><input type = "text" name = "p_addr_country" value = "%s" maxlength = "50"/><br/>
    <input type = "submit" value = "Update"/>
    </form>
    """ % (UName, pdesc, ghandle, p_addr_str1, p_addr_str2, p_addr_minMun, p_addr_majMun, 
    p_addr_govD, p_addr_postalA, p_addr_country)
    #display link
    print ("""<a href = "%s">Address History</a><br/>""" % 
    (redirect.getRelativeURL("ViewAddressHistory.py")))
    print ("""<a href = "%s">Cancel</a>""" % 
    (redirect.getRelativeURL("MyPlayerAccount.py")))
    print """</div>"""
    #-----------------------------------------------------------------------------------------
    # footer + end of document
    print """\
        </div>
        <!-- Footer area with copyright and links -->
        <div id="Footer">
        <div id="FooterContent" class="container">
        <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
        </div>
        </div>        
        </body>
        </html>"""
# clean up
db.close()
sess.close()