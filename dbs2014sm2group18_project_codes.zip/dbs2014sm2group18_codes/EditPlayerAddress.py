# Description: Edit player address details
# Author: Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect, xstr

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
    # not logged in: redirect to Login
    print redirect.getRedirectHead(redirect.getRelativeURL("Login.py"))
    db.close()
    sess.close()
    quit()    

# logged in: validate user
try:
    cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""", sess.data.get('userName'))          
except:
    # database error
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        # invalid user: redirect to do_logout
        print redirect.getRedirectHead(redirect.getRelativeURL("do_logout.py"))
        db.close()
        sess.close()
        quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A', 'P')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
    # access denied
    print redirect.getRedirectHead(redirect.getRelativeURL("AccessDenied.py"))
    db.close()
    sess.close()
    quit()

#=====================================================================================
# Page Head
#=====================================================================================
# head of HTML document
print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

#=====================================================================================
# Page Body
#=====================================================================================
# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
else:
    print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a href="MaintainGames.py">Games</a></li>
    <li><a href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a class="active" href="MaintainPlayer.py">Players</a></li>
    <li><a href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

print "<h1>Edit Player Address</h1>"

# get the current details
sql = """\
SELECT
    StartDate,
    EndDate,
    StreetAddressLine1,
    StreetAddressLine2,
    MinorMuniciplity,
    MajorMuniciplity,
    GoverningDistrict,
    PostCode,
    Country
FROM PlayerAddress
    INNER JOIN Address ON PlayerAddress.AddressID = Address.AddressID
WHERE PlayerAddress.PlayerID = %s AND PlayerAddress.StartDate = %s;
"""

cursor.execute(sql, (form.getfirst('PlayerID'), form.getfirst('StartDate')))
details = cursor.fetchone()


if details != None:
    print """\
        <form action="do_editPlayerAddress.py" name="form" method="post">
        <fieldset>
        <legend>details</legend>
        <table class="form">
        <tbody>"""
    # read only for venue id
    print """<tr><td><label for="PlayerID">Player ID</label></td>"""
    print """<td><input type="text" name="PlayerID" value="%s" readonly></input></td>""" % form.getfirst('PlayerID')
    print "</tr>"

    # text field for Start Date, the StartDate is read only because it is generated by the system, and shouldn't be changed by anyone.
    print """<tr><td><label for="StartDate">Start Date</label></td>"""
    print """<td><input type="date" name="StartDate" value="%s" required readonly></input></td></tr>"""% xstr.xstr(details[0])
    
    # text field for End Date
    print """<tr><td><label for="EndDate">End Date</label></td>"""
    print """<td><input type="date" name="EndDate" value="%s" readonly></input></td></tr>"""% xstr.xstr(details[1])
    
    # text field for addr line 1
    print """<tr><td><label for="addrLine1">Address Line 1</label></td>"""
    print """<td><input type="text" name="addrLine1" value="%s" required></input></td></tr>""" % xstr.xstr(details[2])

    # text field for addr line 2
    print """<tr><td><label for="addrLine2">Address Line 2</label></td>"""
    print """<td><input type="text" name="addrLine2" value="%s" ></input></td></tr>"""% xstr.xstr(details[3])

    # text field for Minor Munici
    print """<tr><td><label for="MinorM">Minor Municiplity</label></td>"""
    print """<td><input type="text" name="MinorM" value="%s" ></input></td></tr>"""% xstr.xstr(details[4])

    # text field for Major Minici
    print """<tr><td><label for="MajorM">Major Municiplity</label></td>"""
    print """<td><input type="text" name="MajorM" value="%s"  required></input></td></tr>"""% xstr.xstr(details[5])
    
    # text field for Governing Destrict
    print """<tr><td><label for="GoverningDistrict">Governing District</label></td>"""
    print """<td><input type="text" name="GoverningDistrict" value="%s" required></input></td></tr>"""% xstr.xstr(details[6])
    
    # text field for Post Code
    print """<tr><td><label for="PostCode">Post Code</label></td>"""
    print """<td><input type="text" name="PostCode" value="%s" required></input></td></tr>"""% xstr.xstr(details[7])
    
    # text field for Country
    print """<tr><td><label for="Country">Country</label></td>"""
    print """<td><input type="text" name="Country" value="%s" required></input></td></tr>"""% xstr.xstr(details[8])
       
    
    print """\
        </tbody>
        </table>
        </fieldset>
        <tr><td><input type="submit" value="Submit"></input></td></tr>
        </form>"""
else:
    print """
    No equipment available
    """
    
#=====================================================================================
# Footer
#=====================================================================================

print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()