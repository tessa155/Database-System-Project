# MaintainInstanceRuns.py
# Description: View details of an InstanceRun, including players, links to edit details and add players
# Author: Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect, traceback

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
	db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
	cursor = db.cursor()
except:
	print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
	sess.close()
	quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
	# not logged in: redirect to Login
	print redirect.getRedirectHead(redirect.getRelativeURL("Login.py"))
	db.close()
	sess.close()
	quit()	

# logged in: validate user
try:
	cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""", sess.data.get('userName'))          
except:
	# database error
	print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
	db.close()
	sess.close()
	quit()
else:
	if (cursor.rowcount != 1):
		# invalid user: redirect to do_logout
		print redirect.getRedirectHead(redirect.getRelativeURL("do_logout.py"))
		db.close()
		sess.close()
		quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A', 'P')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
	# access denied
	print redirect.getRedirectHead(redirect.getRelativeURL("AccessDenied.py"))
	db.close()
	sess.close()
	quit()

#=====================================================================================
# Update logic
#=====================================================================================

sql = """\
UPDATE Equipment
SET Make=%s, Model=%s, EquipmentReview=%s, ProcessorSpeed=%s
WHERE EquipmentID = %s;
"""

params = (form.getfirst('Make'),
          form.getfirst('Model'),
          form.getfirst('EquipmentReview'),
          form.getfirst('ProcessorSpeed'),
          form.getfirst('EquipmentID'))

try:
	cursor = db.cursor()
	cursor.execute(sql, params)
	db.commit()
	cursor.close()
except:
	traceback.print_exc()
	db.rollback()
	cursor.close()
	whereToNext = "EditEquipment.py?id=%s" % form.getfirst('EquipmentID')

else:
	whereToNext = "ViewEquipment.py?id=%s" % form.getfirst('EquipmentID')

print redirect.getRedirectHead(redirect.getRelativeURL(whereToNext))
	
# clean up
db.close()
sess.close()
