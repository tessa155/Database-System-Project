# Script to browse all orders (admin-side)
# Aaron Priestley
# 19 10 2014

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()
    
#===========================================
# LOGIN VALIDATION
#===========================================

# check for login status and details
validUser = False
rdPage = None
message = ""
isCFV = False
isPV = False
if sess.data.get('loggedIn'):
    #check that the user is a viewer
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName = %s
            """, (MySQLdb.escape_string(sess.data.get('userName'))))
    if cursor.rowcount == 1:
        # user is valid viewer, but make checks about subtypes (for later)
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        if (UType == 'A'):
            validUser = True
        else:
            # login detected but not for a viewer, query again to find rdPage
            message = "Redirecting.."
            if UType == 'P':
                # go to a player page
                rdPage = "CreateVideo.py"
            elif UType == 'V':
                # go to an admin page
                rdPage = "BrowseVideos.py"
            else:
                # user of no type found (likely hack), go to logout page
                rdPage = "do_logout.py"
                message = "Logging out.."
    else:
         # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    # no login detected, redirect to login page
    rdPage = "Login.py"
    message = "Redirecting.."

#===========================================
# PAGE DISPLAY AND MAIN CONTENT
#===========================================
        
# redirect if not public or viewer
if (not validUser):
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
else:    
    # head of HTML document
    form = cgi.FieldStorage()
    print """\
        <!doctype html>
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>WWAG</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>"""
    # top bar and accountpanel
    print """\
        <!-- Top bar with account panel (my account | logout) -->
        <div id="TopBar">
        <div id="AccountPanel">"""
    if sess.data.get('loggedIn'):
        print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
    else:
        print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""
    print """\
        </div>
        </div>"""
    # header area
    print """\
        <!-- Header with company logo -->
        <div id="Header">
        <a href="home.py" id="Logo">
        <img src="images/Logo.svg" alt="Logo"/>
        <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
        </a>
        </div>"""
    # main nav
    print """\
        <!-- Main navigation bar -->
        <div id="TopNav">
        <ul>
        <li><a href="MaintainVideos.py">Videos</a></li>
        <li><a href="MaintainInstanceRuns.py">Instance Runs</a></li>
        <li><a href="MaintainGames.py">Games</a></li>
        <li><a href="MaintainVenues.py">Venues</a></li>
        <li><a href="MaintainEquipment.py">Equipment</a></li>
        <li><a href="MaintainPlayer.py">Players</a></li>
        <li><a class="active" href="MaintainViewers.py">Viewers</a></li>
        </ul>
        </div>"""
    # page area
    print """\
        <!-- The main body section of the page -->
        <div id="PageWrapper">"""
    #-----------------------------------------------------------------------------------------
    print """<h1>Maintain Orders</h1>"""
    # get filter information
    viewerFilter = form.getvalue('viewerfilter')
    if viewerFilter == None or viewerFilter == "all":
        filterSQL = None
    else:
        filterSQL = viewerFilter
    # print filter form
    print """ <form action = "MaintainOrders.py" method = "post">
    View orders for: <select name = "viewerfilter">
    <option value = "all">All</option>"""
    cursor.execute(""" SELECT DISTINCT ViewerOrder.ViewerID, User.UserName 
                   FROM ViewerOrder INNER JOIN User
                   ON ViewerOrder.ViewerID = User.UserID
                   ORDER By ViewerID""")
    validViewers = cursor.fetchall()
    for viewer in validViewers:
        print """ <option value = "%s">Viewer %s - %s</option>""" % (viewer[0],
        viewer[0],
        viewer[1])
    print """ <input type = "submit" value = "Filter"/></select></form><br/>"""
    if filterSQL:
        cursor.execute(""" SELECT UserName From User WHERE UserID = %s""", viewerFilter)
        viewername = cursor.fetchone()[0]
    # get viewer order details
    if filterSQL:
        cursor.execute("""
    SELECT DISTINCT ViewerOrder.ViewerOrderID,
    ViewerOrder.OrderDate, ViewerOrder.ViewerID
    FROM ViewerOrder 
    WHERE ViewerOrder.ViewerID = %s
    ORDER BY ViewerOrder.ViewerOrderID
                   """, (viewerFilter))
    else:
        cursor.execute("""
    SELECT DISTINCT ViewerOrder.ViewerOrderID,
    ViewerOrder.OrderDate, ViewerOrder.ViewerID
    FROM ViewerOrder
    ORDER BY ViewerOrder.ViewerOrderID
                   """)
    if cursor.rowcount == 0:
        print """ No orders to display"""
        if filterSQL:
            print """ for viewer %s - %s""" % (viewerFilter, viewername)
    else:
        #orders available to display, get all order items
        orders = cursor.fetchall()
        if filterSQL:
            print """ <h3>Orders for viewer %s - %s:</h3>""" % (viewerFilter, viewername)
        for order in orders:
            cursor.execute(""" SELECT UserName From User WHERE UserID = %s""", order[2])
            viewername = cursor.fetchone()[0]
            print """ Order %s <br/>(Viewer: %s - %s, Date: %s) - """ % (order[0], order[2], 
            viewername, order[1])
            # print management options next to viewer/date info brackets
            print """ <a href = "%s?ViewOrdID=%s">%s</a>""" % ("do_deleteOrder.py", order[0], "Delete Order")
            print """ <table><tr><th>Perk Purchase</th>
            <th>Viewed Status</th>
            <th>Video ID</th>
            <th>InstanceRun ID</th>
            <th>URL</th>
            <th>Video Type</th>
            <th>Price</th>
            <th></th></tr>"""
            # get line items
            cursor.execute("""SELECT ViewerOrderLine.FlagPerk, ViewerOrderLine.ViewedStatus,
                           Video.VideoID, Video.InstanceRunID, Video.URL, Video.VideoType,
                           Video.Price
                           FROM ViewerOrderLine INNER JOIN Video ON 
                           ViewerOrderLine.VideoID = Video.VideoID WHERE
                           ViewerOrderLine.ViewerOrderID = %s""", (order[0]))
            videos = cursor.fetchall()
            # print line items
            for item in videos:
                print "<tr>"
                for i in range(len(item) + 1):
                    if i == 0:
                        perkstatus = 'Yes' if item[i] == 1 else 'No'
                        print """<td>%s</td>""" % (perkstatus)
                    elif i == 1:
                        viewstatus = 'Viewed' if item[i] == 'V' else 'Pending'
                        print """<td>%s</td>""" % (viewstatus)
                    elif i == 4:
                        print """ <td><a href = "http://%s">%s</a></td>""" % (item[4], item[4])
                    elif i == len(item):
                        if len(videos) > 1:
                            print """ <td><a href = "%s?itemID=%s&orderID=%s">%s</a></td>""" % ("do_deleteOrderItem.py", 
                        item[2], order[0], "Remove item")
                        else:
                            print """ <td><a href = "%s?VidOrdID=%s">%s</a></td>""" % ("do_deleteOrder.py", 
                        order[0], "Remove item")
                    else:
                        print """ <td>%s</td>""" % (item[i])
                print "</tr>"
            print """ </table>"""
            # show management options for order
            # print some spacing
            print """ <br/><br/>"""
    #-----------------------------------------------------------------------------------------
    # footer + end of document
    print """\
        </div>
        <!-- Footer area with copyright and links -->
        <div id="Footer">
        <div id="FooterContent" class="container">
        <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
        </div>
        </div>        
        </body>
        </html>"""

# clean up
db.close()
sess.close()