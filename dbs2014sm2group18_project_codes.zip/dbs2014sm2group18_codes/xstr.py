def xstr(s):
    if (s is not None):
        return str(s)
    else:
        return ""
