# The libraries we'll need
import sys, session, cgi, MySQLdb

# Get a DB connection
db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
cursor = db.cursor()

# What came on the URL string?
params = cgi.FieldStorage()

foundParam=0

# Check if the parameter we are looking for was passed
if params.has_key('paramName'):

    foundParam=1

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)
    
# Send head of HTML document, pointing to our style sheet
print """
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Cart</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
"""

# start of body
print """\
    <body>
        <div id="Wrapper">
"""

# TopBar and AccountMenu
print """\
            <div id="TopBar">
                <div id="TopBarContent" class="container">
"""

print """\
    <div id="AccountMenu"><a id="Home" href="home.py">Home</a> | <a href="login.py" id="Login">Login</a></div>
"""

print """\
                </div>
            </div>
"""

# header area
print """\
            <header>
                <div id="HeaderContent" class="container">
                    <a href="home.py" id="Logo">
                    <img src="/images/logo.png" alt="WWAG Logo"/>
                    <span>Will Wheaton Appreciation Guild</span>
                    </a>
                    <div></div>
                </div>
            </header>
"""

print """\
            <br/><br/><br/><br/><br/><br/><br/>
"""


# --- START OF PAGE CONTENT ---
print """\
            <div id="PageContent" class="container">
"""
print """\
    <div id="title"><h1>Cart</h1></div><br/>
"""
print """\
            <h3>INSERT PAGE CONTENT HERE</h3>
"""

# --- END OF PAGE CONTENT ---
print """\
            </div>
"""

print """\
            <br/><br/><br/><br/><br/><br/><br/>
"""

# footer
print """\
            <footer>
                <div id="FooterContent" class="container">
                    <p id="Copyright">&copy; 2014, Database Systems Group 18.</p>
                </div>
            </footer>
"""

# end of html
print """\
        </div>
    </body>
</html>
"""
# Tidy up and free resources
db.close()
sess.close()

