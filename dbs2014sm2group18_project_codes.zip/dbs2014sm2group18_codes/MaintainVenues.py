# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)



form = cgi.FieldStorage()

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    sess.close()
    quit()
    
    

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
    # not logged in: redirect to Login
    print redirect.getRedirectHead(redirect.getRelativeURL("Login.py"))
    db.close()
    sess.close()
    quit()    

# logged in: validate user
try:
    cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""",  sess.data.get('userName'))          
except:
    # database error
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        # invalid user: redirect to do_logout
        print redirect.getRedirectHead(redirect.getRelativeURL("do_logout.py"))
        db.close()
        sess.close()
        quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A', 'P')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
    # access denied
    print redirect.getRedirectHead(redirect.getRelativeURL("AccessDenied.py"))
    db.close()
    sess.close()
    quit()



    
#=====================================================================================
# Page Head
#=====================================================================================

print """\
    <!doctype html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""


#=====================================================================================
# Page Body
#=====================================================================================

# top bar and account panel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
else:
    print """<a id="SignUp" href="CreateVenue.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a href="MaintainGames.py">Games</a></li>
    <li><a class="active" href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a href="MaintainPlayer.py">Players</a></li>
    <li><a href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

if form.getvalue('dropdown'):
    sort = MySQLdb.escape_string(form.getvalue('dropdown'))
else:
    sort = "VenueID"


print """\
            <div id="PageContent" class="container">
"""

print """\
    <h1>Maintain Venues</h1>
    <p style="text-align:right"><a href="CreateVenue.py">Create New Venue</a></p>
"""

print """\
    <form action="MaintainVenues.py" method="post">
        <select name="dropdown">
            <option value="VenueID" selected>Venue ID</option>
            <option value="VenueName" >Venue Name</option>
            <option value="PowerOutlets">Power Outlet</option>
            <option value="VenueSupervisorID">Supervisor ID</option>
        </select>
    <input type="submit" value="Sort"/>
    </form>
"""


sql_select = """ SELECT VenueID, VenueName, PowerOutlets, VenueSupervisorID
                FROM Venue
                INNER JOIN Player
                ON Venue.VenueSupervisorID = Player.PlayerID
                ORDER BY %s ASC""" % sort

cursor.execute(sql_select)

rows = cursor.fetchall()
if (len(rows) > 0):
    print """
    <table>
        <tr>
            <th>Venue ID</th>
            <th>Venue Name</th>
            <th>Power Outlets</th>
            <th>Venue Supervisor ID</th>
        </tr>
    """
    
    for r in rows:
        print "<tr>"
        for cell in r:
            print "<td>%s</td>" % cell
        print "<td><a href=\"ViewVenue.py?id=%s\">View</a> | <a href=\"EditVenue.py?id=%s\">Edit</a>" % (r[0], r[0])
        print "</tr>"
        
    print """\
        </table>
    """
else:
    print """\
        <p>No results<p>
    """


print """
    </table>
"""


# --- END OF PAGE CONTENT ---
print """\
            </div>
"""

print """\
            <br/><br/><br/><br/>
"""


#-----------------------------------------------------------------------------------------

# footer + end of document
print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()
