# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()

validUser = False
rdPage = None
message = ""
if sess.data.get('loggedIn'):
    #check that the user is a viewer
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName == %s
            """, (MySQLdb.escape_string(sess.data.get('userName'))))
    if cursor.rowcount == 1:
        # user is valid viewer, but make checks about subtypes (for later)
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        if (UType == 'V'):
            cursor.execute ("""
                    SELECT *
                    FROM CrowdFundingViewer
                    WHERE ViewerID == %s
                """, (MySQLdb.escape_string(UID)))
            rows = []
            CFVrows = cursor.fetchall()
            isCFV = (len(CFVrows) > 0)
            rows += CFVrows
            cursor.execute ("""
                    SELECT *
                    FROM PremiumViewer
                    WHERE ViewerID == %s
                """, (MySQLdb.escape_string(UID)))
            PVrows = cursor.fetchall()
            isPV = (len(PVrows) > 0)
            rows += PVrows
            validUser = True
            else:
                        # login detected but not for a viewer, query again to find rdPage
                message = "Redirecting.."
                if UType == 'P':
                    # go to a player page
                    rdPage = "CreateVideo.py"
                elif UType == 'A':
                    # go to an admin page
                    rdPage = "MaintainVideo.py"
                else:
                    # user of no type found (likely hack), go to logout page
                    rdPage = "do_logout.py"
                    message = "Logging out.."
    else:
         # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    # no login detected, redirect to login page
    rdPage = "Login.py"
    message = "Redirecting.."
        
if not validUser:
    cursor.close()
    db.close()
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
else:    
    # head of HTML document
    print """\
        <!doctype html>
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>WWAG</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>"""
    # top bar and accountpanel
    print """\
        <!-- Top bar with account panel (my account | logout) -->
        <div id="TopBar">
        <div id="AccountPanel">"""
    if sess.data.get('loggedIn'):
        print """Welcome, <a href="account.py">Username</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
    else:
        print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""
    print """\
        </div>
        </div>"""
    # header area
    print """\
        <!-- Header with company logo -->
        <div id="Header">
        <a href="home.py" id="Logo">
        <img src="http://placehold.it/200x100 alt="Logo"/>
        <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
        </a>
        </div>"""
    # main nav
    print """\
        <!-- Main navigation bar -->
        <div id="TopNav">
        <ul>
        <li><a class="active" href="BrowseVideos.py">Videos</a></li>
        <li><a href="Players.py">Players</a></li>
        <li><a href="Games.py">Games</a></li>
        <li><a href="Venues.py">Venues</a></li>
        <li><a href="Equipment.py">Equipment</a></li>
        <li><a href="About.py">About</a></li>
        </ul>
        </div>"""
    # page area
    print """\
        <!-- The main body section of the page -->
        <div id="PageWrapper">"""
    #-----------------------------------------------------------------------------------------
    #get cart data from cookie
    try:
        cartItms = sess.data.get('cart').split(';')
    except:
        cartItms = []
    #get previous order data for user if CFV or PV
    CFVOrders = []
    PVOrders = []
    if isCFV or isPV:
        cursor.execute("""SELECT Video.VideoID,
    VideoOrderLine.ViewedStatus
    ViewerOrderLine.FlagPerk
    FROM Video
    NATURAL JOIN ViewerOrderLine
    NATURAL JOIN ViewerOrder
    WHERE
    ViewerOrder.ViewerID == %s
    """, UID)
        if cursor.rowcount > 0:
            rows = cursor.fetchall()
        else:
            rows = []
        for item in rows:
            if item[2] == True:
                CFVOrders.add(item)
            else:
                PVOrders.add(item)
    #display list of videos
    cursor.execute("""
    SELECT Video.VideoID, 
    InstanceRun.InstanceRunName AS InstanceName, 
    InstanceRun.CategoryName AS Category,
    Video.VideoType As VideoType,
    Game.GameTitle As Game,
    Game.Genre As Genre, 
    Game.PromotionLink As GameURL
    Game.StarRating As GameRating
    Video.VideoID As ID,
    Video.Price As Price,
    VideoOrderLine.ViewedStatus As Viewed,
    VideoOrderLine.FlagPerk As Perk
    Video.URL As VideoURL
    FROM Video
    """)
    if cursor.rowcount == 0:
        print """No videos to show
        """
    else:
        videodata = cursor.fetchall()
        print "<table>"
        print """<tr>
        <th>Instance Name</th>
        <th>Category</th>
        <th>Video Type</th>
        <th>Game</th>
        <th>Genre</th>
        <th>URL</th>
        <th>Rating</th>
        <th>Status</th>
        <th><th>
        </tr>
        """
        for video in videodata:
            print "<tr>"
            for i in range(1,len(video)-3):
                # check status of item (in order, cart or purchased, or show 
                # price)
                print "<td>"
                if i == len(video) - 4:
                    # check if premium item
                    if video[8] == 0:
                        # standard item
                        print "Free"
                        print ("""</td><td><a href = "%s">View</a>""" % 
                            (video[12]))
                    else:
                        # check if item has been purchased
                        isPurch = False
                        for j in range(CFVOrders):
                            if video[8] == CFVOrders[j][0]:
                                isPurch = True
                                print "%s" % (video[10])
                                print ("""</td><td><a href = "%s">View</a>""" % 
                                    (video[12]))
                        for j in range(PVOrders):
                            if (not isPurch):
                                for j in range(PVOrders):
                                if video[8] == PVOrders[j][0]:
                                    isPurch = True
                                    print "%s" % (video[10])
                                    print ("""</td><td><a href = "%s">View</a>""" % 
                                        (video[12]))
                        if (not isPurch):
                            if (isCFV or isPV):
                                print "Price: %s" % (video[9])
                                print ("""</td><td>Add to cart: 
                                <input type = "checkbox" value = "%s"/>""" % 
                                    (video[8]))
                            else:
                                print "Price: %s" % (video[9])
                                print ("""</td><td><a href = "%s">Update Account</a>""" 
                                % ("MyViewerAccount.py"))
                    print "</td>"
            print "</tr>"
        print "</table>"
    #-----------------------------------------------------------------------------------------
    # footer + end of document
    print """\
        </div>
        <!-- Footer area with copyright and links -->
        <div id="Footer">
        <div id="FooterContent" class="container">
        <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
        </div>
        </div>        
        </body>
        </html>"""
# clean up
db.close()
sess.close()