# ViewInstanceRun.py
# Description: View instance Run details
# Author: Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
    # not logged in: redirect to Login
    print redirect.getRedirectHead(redirect.getRelativeURL("Login.py"))
    db.close()
    sess.close()
    quit()    

# logged in: validate user
try:
    cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""", sess.data.get('userName'))          
except:
    # database error
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        # invalid user: redirect to do_logout
        print redirect.getRedirectHead(redirect.getRelativeURL("do_logout.py"))
        db.close()
        sess.close()
        quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A', 'P')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
    # access denied
    print redirect.getRedirectHead(redirect.getRelativeURL("AccessDenied.py"))
    db.close()
    sess.close()
    quit()

#=====================================================================================
# id Validation
#=====================================================================================
sql = """\
SELECT * FROM InstanceRun
WHERE InstanceRunID = %s;"""

try:
    cursor.execute(sql, form.getfirst('id'))
except:
    print redirect.getRedirectHead(redirect.getRelativeURL("dberror.py"))
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        print redirect.getRedirectHead(redirect.getRelativeURL("ManageInstanceRuns.py"))
        db.close()
        sess.close()
        quit()
    else:
        instanceRunDetails = cursor.fetchone()

#=====================================================================================
# Page Head
#=====================================================================================
# head of HTML document
print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

#=====================================================================================
# Page Body
#=====================================================================================
# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
else:
    print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a class="active" href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a href="MaintainGames.py">Games</a></li>
    <li><a href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a href="MaintainPlayer.py">Players</a></li>
    <li><a href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

# InstanceRun details
print """<h1>Instance Run Details</h1>"""
print """<h2>Details</h2>"""

sql = """\
SELECT
    InstanceRunID,
    concat(Supervisor.FirstName, ' \"', Supervisor.GameHandle, '\" ', Supervisor.LastName),
    InstanceRunName,
    RecordedTime,
    CategoryName,
    Game.GameTitle,
    Venue.VenueName
FROM InstanceRun
    INNER JOIN Player as Supervisor ON InstanceRun.SupervisorID = Supervisor.PlayerID
    INNER JOIN Game ON InstanceRun.GameID = Game.GameID
    INNER JOIN Venue ON InstanceRun.VenueID = Venue.VenueID
WHERE InstanceRunID = %s;
"""

try:             
    cursor.execute(sql, form.getvalue('id'))
except:
    print """\
        <p>We could not process your query.<p>"""
        
else:
    if (cursor.rowcount == 1):
        instanceRunDetails = cursor.fetchone()
        print """\
            <table class="details">
            <tbody>
                    <tr><td>ID</td><td>%s</td></tr>
                    <tr><td>Supervisor</td><td>%s</td></tr>
                    <tr><td>Name</td><td>%s</td></tr>
                    <tr><td>Recorded Time</td><td>%s</td></tr>
                    <tr><td>Category</td><td>%s</td></tr>
                    <tr><td>Game</td><td>%s</td></tr>
                    <tr><td>Venue</td><td>%s</td></tr>
            </tbody>
            </table>""" % (instanceRunDetails[0],instanceRunDetails[1],instanceRunDetails[2],instanceRunDetails[3],instanceRunDetails[4],instanceRunDetails[5],instanceRunDetails[6])
            
        print """<p><a href="EditInstanceRun.py?id=%s">Edit details</a></p>""" % form.getfirst('id')
        
    else:
        print """<p>No record exists.</p>"""

        
# Achievements
print """<hr/>"""
print """<h2>Achievements</h2>"""

sql = """\
SELECT AchievementID,
    AchievementName,
    WhenAchieved,
    RewardBody
FROM Achievement
WHERE InstanceRunID = %s;"""

try:             
    cursor.execute(sql, form.getvalue('id'))

except:
    print """\
        <p>There was an error finding InstanceRunPlayers.<p>"""

else:
    if (cursor.rowcount != 0):
        print """\
            <table>
            <thead>
                <tr>
                    <th>Achievement ID</th>
                    <th>Achievement name</th>
                    <th>When achieved</th>
                    <th>Rewarding body</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>"""

        for row in cursor.fetchall():
            print "<tr>"
            for cell in row:
                print "<td>%s</td>" % cell
            print "<td><a href=\"EditAchievement.py?id=%s\">Edit</a>" % (row[0])
            print "</tr>"

        print """\
            </tbody>
            </table>"""

    else:
        print """\
            <p>There are no achievements recorded for this instance run.<p>"""

print """<p><a href="CreateAchievement.py?id=%s">Add achievement</a></p>""" % form.getfirst('id')


# InstanceRunPlayers
print """<hr/>"""
print """<h2>Instance Run Players</h2>"""

sql = """\
SELECT Player.PlayerID,
    concat(Player.FirstName, ' \"', Player.GameHandle, '\" ', Player.LastName),
    concat(Equipment.Make, ' ', Equipment.Model),
    InstanceRunPlayer.PerformanceNotes
FROM InstanceRunPlayer
    INNER JOIN Player ON InstanceRunPlayer.PlayerID = Player.PlayerID
    LEFT OUTER JOIN Equipment ON InstanceRunPlayer.EquipmentID = Equipment.EquipmentID
WHERE InstanceRunPlayer.InstanceRunID = %s;"""

try:             
    cursor.execute(sql, form.getvalue('id'))

except:
    print """\
        <p>There was an error finding InstanceRunPlayers.<p>"""

else:
    if (cursor.rowcount != 0):
        print """\
            <table>
            <thead>
                <tr>
                    <th>Player ID</th>
                    <th>Player Name</th>
                    <th>Player Equipment</th>
                    <th>Performance Notes</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>"""

        for row in cursor.fetchall():
            print "<tr>"
            for cell in row:
                print "<td>%s</td>" % cell
            print "<td><a href=\"ViewInstanceRunPlayer.py?pid=%s&irid=%s\">View</a> | <a href=\"EditInstanceRunPlayer.py?pid=%s&irid=%s\">Edit</a>" % (row[0], form.getvalue('id'), row[0], form.getvalue('id'))
            print "</tr>"

        print """\
            </tbody>
            </table>"""

    else:
        print """\
            <p>This Instance Run has no Players.<p>"""

print """<p><a href="CreateInstanceRunPlayer.py?id=%s">Add player</a></p>""" % form.getfirst('id')



#=====================================================================================
# Footer
#=====================================================================================

print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()
