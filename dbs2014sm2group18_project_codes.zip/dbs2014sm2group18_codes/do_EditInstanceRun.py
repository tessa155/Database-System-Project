# MaintainInstanceRuns.py
# Description: View details of an InstanceRun, including players, links to edit details and add players
# Author: Malcolm Karutz

# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
    # not logged in: redirect to Login
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("Login.py")
    db.close()
    sess.close()
    quit()    

# logged in: validate user
try:
    cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""", sess.data.get('userName'))          
except:
    # database error
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        # invalid user: redirect to do_logout
        print """\
            <!DOCTYPE html>
            <html>
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
            """ % redirect.getRelativeURL("do_logout.py")
        db.close()
        sess.close()
        quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A', 'P')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
    # access denied
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("AccessDenied.py")
    db.close()
    sess.close()
    quit()

#=====================================================================================
# Parameter Validation
#=====================================================================================
# if no id passed, redirect to ManageInstanceRuns.py
if (not form.has_key('InstanceRunID')):
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("MaintainInstanceRuns.py")
    sess.close()
    quit()
else:
    ID = form.getfirst('InstanceRunID')

#=====================================================================================
# Update logic
#=====================================================================================

try:
    cursor.execute("""BEGIN""")
    cursor.execute("""UPDATE InstanceRun
                        SET SupervisorID=%s,
                              InstanceRunName=%s,
                              RecordedTime=%s,
                              CategoryName=%s,
                              GameID=%s,
                              VenueID=%s
                            WHERE InstanceRunID=%s""", (form.getvalue('SupervisorID'),
                                                        form.getvalue('InstanceRunName'),
                                                        form.getvalue('RecordedTime'),
                                                        form.getvalue('CategoryName'),
                                                        form.getvalue('GameID'),
                                                        form.getvalue('VenueID'),
                                                        ID))
    db.commit()
except:
    db.rollback()
    whereToNext = "EditInstanceRun.py?id=%s" % form.getvalue('InstanceRunID')

else:
    whereToNext = "ViewInstanceRun.py?id=%s" % form.getvalue('InstanceRunID')

print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="refresh" content="0;url=%s">
    </head>
    <body>
    </body>
    """ % redirect.getRelativeURL(whereToNext)
    
# clean up
db.close()
sess.close()
