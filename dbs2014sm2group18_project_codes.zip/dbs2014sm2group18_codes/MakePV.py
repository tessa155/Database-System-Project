# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Maintain the session
sess = session.Session(expires=20*60, cookie_path='/')

# What came on the URL string?
form = cgi.FieldStorage()

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    sess.close()
    quit()

#=====================================================================================
# Session Validation
#=====================================================================================
# check login
if (not sess.data.get('loggedIn')):
    # not logged in: redirect to Login
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("Login.py")
    db.close()
    sess.close()
    quit()    

# logged in: validate user
try:
    cursor.execute("""SELECT UserID, UserType
                    FROM User
                    WHERE UserName = %s;""", sess.data.get('userName'))          
except:
    # database error
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    db.close()
    sess.close()
    quit()
else:
    if (cursor.rowcount != 1):
        # invalid user: redirect to do_logout
        print """\
            <!DOCTYPE html>
            <html>
            <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <meta http-equiv="refresh" content="0;url=%s">
            </head>
            <body>
            </body>
            """ % redirect.getRelativeURL("do_logout.py")
        db.close()
        sess.close()
        quit()

# user validated: get usertype
USER_TYPES_ALLOWED = ('A', 'P')
sessionUserInfo = cursor.fetchone()
sessionUserID   = sessionUserInfo[0]
sessionUserType = sessionUserInfo[1]
if (sessionUserType not in USER_TYPES_ALLOWED):
    # access denied
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("AccessDenied.py")
    db.close()
    sess.close()
    quit()

#=====================================================================================
# Parameter Validation
#=====================================================================================
# if no id passed, redirect to MaintainViewers.py
if (not form.has_key('id')):
    print """\
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("MaintainViewers.py")
    sess.close()
    quit()
else:
    ID = form.getfirst('id')

#=====================================================================================
# Page Head
#=====================================================================================
# head of HTML document
print """\
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>WWAG</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>"""

#=====================================================================================
# Page Body
#=====================================================================================
# top bar and accountpanel
print """\
    <!-- Top bar with account panel (my account | logout) -->
    <div id="TopBar">
    <div id="AccountPanel">"""

if sess.data.get('loggedIn'):
    print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
else:
    print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""

print """\
    </div>
    </div>"""

# header area
print """\
    <!-- Header with company logo -->
    <div id="Header">
    <a href="home.py" id="Logo">
    <img src="images/Logo.svg" alt="Logo"/>
    <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
    </a>
    </div>"""

# main nav
print """\
    <!-- Main navigation bar -->
    <div id="TopNav">
    <ul>
    <li><a href="MaintainVideos.py">Videos</a></li>
    <li><a href="MaintainInstanceRuns.py">Instance Runs</a></li>
    <li><a href="MaintainGames.py">Games</a></li>
    <li><a href="MaintainVenues.py">Venues</a></li>
    <li><a href="MaintainEquipment.py">Equipment</a></li>
    <li><a href="MaintainPlayer.py">Players</a></li>
    <li><a class="active" href="MaintainViewers.py">Viewers</a></li>
    </ul>
    </div>"""

# page area
print """\
    <!-- The main body section of the page -->
    <div id="PageWrapper">"""
            
#=====================================================================================
# Main Content
#=====================================================================================

print """<h1>Make Premium Viewer</h1>"""


# record found, print form
GameDetails = cursor.fetchone()
print """\
    <form action="do_makePV.py" name="form" method="post">
        <fieldset>
        <legend>Game details</legend>
            <table class="form">
                <tbody>"""


# input for UserID
print"""\
    <tr>
        <td><label for="UserID">User ID</label></td>
        <td><input type="text" name="UserID" value="%s" readonly></input></td>
    </tr>""" % ID


# input for Subscription
print"""\
    <tr>
        <td><label for="RenewableDate">Renewable Date</label></td>
        <td><input type="date" name="RenewableDate" required></input></td>
    </tr>"""


# input for addr line1
print"""\
    <tr>
        <td><label for="addrLine1">Address Line 1</label></td>
        <td><input type="text" name="addrLine1" required></input></td>
    </tr>"""

# input for addr line2
print"""\
    <tr>
        <td><label for="addrLine2">Address Line 2</label></td>
        <td><input type="text" name="addrLine2" ></input></td>
    </tr>"""

# input for minor munici
print"""\
    <tr>
        <td><label for="MinorM">Minor Municiplity</label></td>
        <td><input type="text" name="MinorM" ></input></td>
    </tr>"""

# input for Major Munici
print"""\
    <tr>
        <td><label for="MajorM">Major Municiplity</label></td>
        <td><input type="text" name="MajorM" required></input></td>
    </tr>"""

# input for Governing District
print"""\
    <tr>
        <td><label for="GoverningDistrict">Governing District</label></td>
        <td><input type="text" name="GoverningDistrict" required></input></td>
    </tr>"""

# input for Post Code
print"""\
    <tr>
        <td><label for="PostCode">Post Code</label></td>
        <td><input type="text" name="PostCode" required></input></td>
    </tr>"""

# input for Country
print"""\
    <tr>
        <td><label for="Country">Country</label></td>
        <td><input type="text" name="Country" required></input></td>
    </tr>"""



print """\
                    </tbody>
                </table>
        </fieldset>
        <tr><td><input type="submit" value="Submit"></input></td></tr>
    </form>"""



#=====================================================================================
# Footer
#=====================================================================================

print """\
    </div>
    <!-- Footer area with copyright and links -->
    <div id="Footer">
    <div id="FooterContent" class="container">
    <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
    </div>
    </div>        
    </body>
    </html>"""

# clean up
db.close()
sess.close()

