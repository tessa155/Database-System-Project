# The libraries we'll need
import sys, session, cgi, MySQLdb, redirect

# Manage the session
sess = session.Session(expires=20*60, cookie_path='/')

# send session cookie
print "%s\nContent-Type: text/html\n" % (sess.cookie)

# Get a DB connection
try:
    db = MySQLdb.connect("info20003db.eng.unimelb.edu.au", "info20003g18", "$DeltaSierraP1$", "info20003g18", 3306)
    cursor = db.cursor()
except:
    print """\
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="refresh" content="0;url=%s">
        </head>
        <body>
        </body>
        """ % redirect.getRelativeURL("dberror.py")
    quit()

#===========================================
# LOGIN VALIDATION
#===========================================
    
validUser = False
rdPage = None
message = ""
if sess.data.get('loggedIn'):
    #check that the user is a viewer. if not a viewer, redirect
    cursor.execute ("""
                SELECT UserID, UserName, UserType
                FROM User
                WHERE UserName = %s
            """, sess.data.get('userName'))
    if cursor.rowcount == 1:
        row = cursor.fetchone()
        UID = row[0]
        UName = row[1]
        UType = row[2]
        if UType == 'V':
            # user is valid viewer, however check that they are a subtype
            cursor.execute ("""
                    SELECT *
                    FROM CrowdFundingViewer
                    WHERE ViewerID = %s
                """, UID)
            rows = []
            CFVrows = cursor.fetchall()
            isCFV = (len(CFVrows) > 0)
            rows += CFVrows
            cursor.execute ("""
                    SELECT *
                    FROM PremiumViewer
                    WHERE ViewerID = %s
                """, UID)
            PVrows = cursor.fetchall()
            isPV = (len(PVrows) > 0)
            rows += PVrows
            if (len(rows) > 0):
                #user is a subtype of viewer, they are valid for this page
                validUser = True
            else:
                rdPage = "BrowseVideos.py"
        else:
            # login detected but not for a viewer, query again to find rdPage
            message = "Redirecting.."
            if UType == 'P':
                # go to a player page
                rdPage = "CreateVideo.py"
            elif UType == 'A':
                # go to an admin page
                rdPage = "MaintainVideo.py"
            else:
                # user of no type found (likely hack), go to logout page
                rdPage = "do_logout.py"
                message = "Logging out.."
    else:
        # user of no type found (likely hack), go to logout page
        rdPage = "do_logout.py"
        message = "Logging out.."
else:
    rdPage = "Login.py"
    message = "Redirecting.."
    
#===========================================
# PAGE DISPLAY AND MAIN CONTENT
#===========================================
        
if not validUser:
    print """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0;url=%s">
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
%s
</body>
""" % (redirect.getRelativeURL(rdPage),message)
else:    
    # head of HTML document
    print """\
        <!doctype html>
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>WWAG</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
        </head>
        <body>"""
    # top bar and accountpanel
    print """\
        <!-- Top bar with account panel (my account | logout) -->
        <div id="TopBar">
        <div id="AccountPanel">"""
    if sess.data.get('loggedIn'):
        print """Welcome, <a href="account.py">%s</a> | <a href="logout.py">Logout</a>""" % sess.data.get('userName')
    else:
        print """<a id="SignUp" href="CreateUserAccount.py">Sign up</a> | <a href="Login.py" id="Login">Login</a>"""
    print """\
        </div>
        </div>"""
    # header area
    print """\
        <!-- Header with company logo -->
        <div id="Header">
        <a href="home.py" id="Logo">
        <img src="images/Logo.svg" alt="Logo"/>
        <span id="CompanyTitle">Will Wheaton Appreciation Guild</span>
        </a>
        </div>"""
    # main nav
    print """\
        <!-- Main navigation bar -->
        <div id="TopNav">
        <ul>
        <li><a class="active" href="BrowseVideos.py">Videos</a></li>
        <li><a href="Players.py">Players</a></li>
        <li><a href="Games.py">Games</a></li>
        <li><a href="Venues.py">Venues</a></li>
        <li><a href="Equipment.py">Equipment</a></li>
        <li><a href="About.py">About</a></li>
        </ul>
        </div>"""
    # page area
    print """\
        <!-- The main body section of the page -->
        <div id="PageWrapper">"""
    #-----------------------------------------------------------------------------------------
    #get cart data from cookie
    try:
        cartItms = sess.data['cart'].split(';')
    except:
        cartItms = []
    if (isCFV):
        cursor.execute(""" SELECT PerkCreditBalance 
                       FROM CrowdFundingViewer WHERE ViewerID = %s""", UID)
        balance = float(cursor.fetchone()[0])
    # print cart contents in tabular format
    print """<div id = "heading_cart"><h2>Cart</h2></div>
    <div id = "cart_content">"""
    # build table of cart items (with description of items)
    if cartItms != None and cartItms != []:
        print "<table>"
        # build table of cart items, print header
        print """<tr>
        <th>Instance Name</th>
        <th>Category</th>
        <th>Price</th>
        <th>Video Type</th>
        <th>Game</th>
        <th>Genre</th>
        <th>Rating</th>
        </tr>
        """
        # get information from database and cartItms
        for item in cartItms:
            print "<tr>"
            # get relevant data for video and display in table row
            # query TBC
            try:
                VID = item
                cursor.execute("""
                SELECT InstanceRun.InstanceRunName AS InstanceName, 
                InstanceRun.CategoryName AS Category,
                Video.Price As Price, 
                Video.VideoType As VideoType,
                Game.GameTitle As Game,
                Game.Genre As Genre, 
                Game.StarRating As GameRating
                FROM Video NATURAL JOIN InstanceRun NATURAL JOIN Game
                WHERE VideoID = %s
            """,VID)
                if (cursor.rowcount != 1):
                    # video not found
                    raise Exception
                else:
                    # get data and display in table
                    row = cursor.fetchone()
                    for i in range(len(row)):
                        print "<td>"
                        print "%s" % (row[i])
                        print "</td>"
            except:
                print """ <td>ERROR: Cannot display item<td>"""
            print "</tr>"
        print "</table><br/>"
        print """
        <form id = "submit_cart_order" action = "do_placeOrder.py" method = "post">
        """
        if (isCFV):
            print """ Use Perk balance: <input name = "usePerk" type = "checkbox"/><br/> 
            Balance: %s<br/>""" % (balance)
        print """
        <input type = "submit" value = "Order"/>
        <a href = "%s">View Orders</a>, <a href = "%s">Clear Cart</a>
        </form>
        """ % ("MyOrders.py", "do_wipeCart.py")
    else:
        print """No items to show (<a href = "%s">View Orders</a>)""" % ("MyOrders.py")
    print """</div>
    
    """
    #-----------------------------------------------------------------------------------------
    # footer + end of document
    print """\
        </div>
        <!-- Footer area with copyright and links -->
        <div id="Footer">
        <div id="FooterContent" class="container">
        <span id="copyright">&copy; 2014, Database Systems Group 18.</span>
        </div>
        </div>        
        </body>
        </html>"""
# clean up
db.close()
sess.close()